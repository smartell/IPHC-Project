  //
  #include <admodel.h>
  // Ian: adding all the IPHC libraries directly
  //#include <ourlib.hpp>
  #include <approx.cpp>
  #include <sq.cpp>
  #include <pen2diffs.cpp>
  #include <CalcRSS.cpp>
  #include <SmearAges.cpp>
  #include <CalcRRSS.cpp>
  // Global container for simulation flag.
  int Simulation = 0;
  // Symbolic constants.
  # define NA -99.0 // Missing data or prediction.
  # define CheckValue -12345  // Place marker in .dat and .pin files.
  # define Sex1 1   // Identifies sex as an index in array declarations.
  # define Sex2 2
  # define Sex3 3
  //
#include <admodel.h>

  extern "C"  {
    void ad_boundf(int i);
  }
#include <legacy.htp>

model_data::model_data(int argc,char * argv[]) : ad_comm(argc,argv)
{
  SimFlag.allocate("SimFlag");
  Area.allocate("Area");
  FirstYear.allocate("FirstYear");
  LastYear.allocate("LastYear");
  SLptN.allocate("SLptN");
  SLptList.allocate(1,SLptN,"SLptList");
  SLptOne.allocate("SLptOne");
  FSelL.allocate(1,SLptN,"FSelL");
  CFParMin.allocate("CFParMin");
  CFParMax.allocate("CFParMax");
  CQEstN.allocate("CQEstN");
  CQEstYears.allocate(1,CQEstN,"CQEstYears");
  CQEstPathTypes.allocate(1,CQEstN,"CQEstPathTypes");
  SteadyCQ_SD.allocate("SteadyCQ_SD");
  HookCorrMax.allocate("HookCorrMax");
  CSelLEstN.allocate("CSelLEstN");
  CSelLEstYears.allocate(1,CSelLEstN,"CSelLEstYears");
  CSelLEstPathTypes.allocate(1,CSelLEstN,"CSelLEstPathTypes");
  CSelLForm.allocate("CSelLForm");
  SQEstN.allocate("SQEstN");
  SQEstYears.allocate(1,SQEstN,"SQEstYears");
  SQEstPathTypes.allocate(1,SQEstN,"SQEstPathTypes");
  SteadySQFlag.allocate("SteadySQFlag");
  SteadySQ_SD.allocate("SteadySQ_SD");
  TrendlessSQFlag.allocate("TrendlessSQFlag");
  SSelLEstN.allocate("SSelLEstN");
  SSelLEstYears.allocate(1,SSelLEstN,"SSelLEstYears");
  SSelLEstPathTypes.allocate(1,SSelLEstN,"SSelLEstPathTypes");
  SSelLForm.allocate("SSelLForm");
  BLptN.allocate("BLptN");
  BLptList.allocate(1,BLptN,"BLptList");
  BLptOne.allocate("BLptOne");
  BSelLEstN.allocate("BSelLEstN");
  BSelLEstYears.allocate(1,BSelLEstN,"BSelLEstYears");
  BSelLEstPathTypes.allocate(1,BSelLEstN,"BSelLEstPathTypes");
  FitBycatchNosFlag.allocate("FitBycatchNosFlag");
  RMMax.allocate("RMMax");
  SmearAgesFlag.allocate("SmearAgesFlag");
  SelSmoothFlag.allocate("SelSmoothFlag");
  SelSmooth_SD.allocate("SelSmooth_SD");
  CatchTau_T.allocate("CatchTau_T");
  CatchTau_F.allocate("CatchTau_F");
  CatchTau_M.allocate("CatchTau_M");
  CCPUETau_T.allocate("CCPUETau_T");
  CCPUETau_F.allocate("CCPUETau_F");
  CCPUETau_M.allocate("CCPUETau_M");
  CCPUETotTau.allocate("CCPUETotTau");
  CWPUETotTau.allocate("CWPUETotTau");
  SurvPropTau_T.allocate("SurvPropTau_T");
  SurvPropTau_F.allocate("SurvPropTau_F");
  SurvPropTau_M.allocate("SurvPropTau_M");
  SurvCPUETau_T.allocate("SurvCPUETau_T");
  SurvCPUETau_F.allocate("SurvCPUETau_F");
  SurvCPUETau_M.allocate("SurvCPUETau_M");
  SurvCPUETotTau.allocate("SurvCPUETotTau");
  SurvWPUETotTau.allocate("SurvWPUETotTau");
  BycatchTau.allocate("BycatchTau");
  RobustifyFlag.allocate("RobustifyFlag");
  CatchLambda.allocate("CatchLambda");
  CCPUELambda.allocate("CCPUELambda");
  CCPUETotLambda.allocate("CCPUETotLambda");
  CWPUETotLambda.allocate("CWPUETotLambda");
  SurvPropLambda.allocate("SurvPropLambda");
  SurvCPUELambda.allocate("SurvCPUELambda");
  SurvCPUETotLambda.allocate("SurvCPUETotLambda");
  SurvWPUETotLambda.allocate("SurvWPUETotLambda");
  BycatchLambda.allocate("BycatchLambda");
  EstMFlag.allocate("EstMFlag");
  EstMMFlag.allocate("EstMMFlag");
  SexFlag.allocate("SexFlag");
  CLastYearFit.allocate("CLastYearFit");
  SLastYearFit.allocate("SLastYearFit");
  FitLastFFlag.allocate("FitLastFFlag");
  LastF.allocate("LastF");
  FitCatchNFlag.allocate("FitCatchNFlag");
  SplitMalesFlag.allocate("SplitMalesFlag");
  DataCheck1.allocate("DataCheck1");
  if (DataCheck1 != CheckValue)
     {
     cerr << "Flags and settings are not in order." << endl;
     exit(1);
     } else
     cout << "Flags and settings are in order." << endl;
  YearFirstDat.allocate("YearFirstDat");
  YearLastDat.allocate("YearLastDat");
  AgeMinDat.allocate("AgeMinDat");
  AgeMaxDat.allocate("AgeMaxDat");
  AgePlusSurf.allocate("AgePlusSurf");
  AgePlusBurn.allocate("AgePlusBurn");
  AgeTrueMinDat.allocate("AgeTrueMinDat");
  AgeTrueMaxDat.allocate("AgeTrueMaxDat");
  LintBN.allocate("LintBN");
  LintBList.allocate(1,LintBN,"LintBList");
  Catch_F_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"Catch_F_Dat");
  Catch_M_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"Catch_M_Dat");
  Catch_T_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"Catch_T_Dat");
  Catch_SE_F_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"Catch_SE_F_Dat");
  Catch_SE_M_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"Catch_SE_M_Dat");
  Catch_SE_T_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"Catch_SE_T_Dat");
  CCPUE_F_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CCPUE_F_Dat");
  CCPUE_M_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CCPUE_M_Dat");
  CCPUE_T_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CCPUE_T_Dat");
  CCPUE_SE_F_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CCPUE_SE_F_Dat");
  CCPUE_SE_M_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CCPUE_SE_M_Dat");
  CCPUE_SE_T_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CCPUE_SE_T_Dat");
  CatchW_F.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CatchW_F");
  CatchW_M.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CatchW_M");
  CatchW_T.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"CatchW_T");
  CatchWTrue_F.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"CatchWTrue_F");
  CatchWTrue_M.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"CatchWTrue_M");
  CatchWTrue_T.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"CatchWTrue_T");
  CCPUETot_Dat.allocate(YearFirstDat,YearLastDat,"CCPUETot_Dat");
  CCPUETot_SE_Dat.allocate(YearFirstDat,YearLastDat,"CCPUETot_SE_Dat");
  CWPUETot_Dat.allocate(YearFirstDat,YearLastDat,"CWPUETot_Dat");
  CWPUETot_SE_Dat.allocate(YearFirstDat,YearLastDat,"CWPUETot_SE_Dat");
  SurvProp_F_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvProp_F_Dat");
  SurvProp_M_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvProp_M_Dat");
  SurvProp_T_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvProp_T_Dat");
  SurvProp_SE_F_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvProp_SE_F_Dat");
  SurvProp_SE_M_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvProp_SE_M_Dat");
  SurvProp_SE_T_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvProp_SE_T_Dat");
  SurvCPUE_F_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvCPUE_F_Dat");
  SurvCPUE_M_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvCPUE_M_Dat");
  SurvCPUE_T_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvCPUE_T_Dat");
  SurvCPUE_SE_F_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvCPUE_SE_F_Dat");
  SurvCPUE_SE_M_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvCPUE_SE_M_Dat");
  SurvCPUE_SE_T_Dat.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvCPUE_SE_T_Dat");
  SurvCPUETot_Dat.allocate(YearFirstDat,YearLastDat,"SurvCPUETot_Dat");
  SurvCPUETot_SE_Dat.allocate(YearFirstDat,YearLastDat,"SurvCPUETot_SE_Dat");
  SurvWPUETot_Dat.allocate(YearFirstDat,YearLastDat,"SurvWPUETot_Dat");
  SurvWPUETot_SE_Dat.allocate(YearFirstDat,YearLastDat,"SurvWPUETot_SE_Dat");
  SurvL_F.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvL_F");
  SurvL_M.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvL_M");
  SurvL_T.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvL_T");
  SurvLTrue_F.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"SurvLTrue_F");
  SurvLTrue_M.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"SurvLTrue_M");
  SurvLTrue_T.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"SurvLTrue_T");
  SurvW_F.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvW_F");
  SurvW_M.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvW_M");
  SurvW_T.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvW_T");
  SurvWTrue_F.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"SurvWTrue_F");
  SurvWTrue_M.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"SurvWTrue_M");
  SurvWTrue_T.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"SurvWTrue_T");
  SurvPropLegal_F.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvPropLegal_F");
  SurvPropLegal_M.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvPropLegal_M");
  SurvPropLegal_T.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvPropLegal_T");
  SurvLegalW_F.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvLegalW_F");
  SurvLegalW_M.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvLegalW_M");
  SurvLegalW_T.allocate(YearFirstDat,YearLastDat,AgeMinDat,AgeMaxDat,"SurvLegalW_T");
  Bycatch_Dat.allocate(YearFirstDat,YearLastDat,1,BLptN,"Bycatch_Dat");
  Bycatch_SE_Dat.allocate(YearFirstDat,YearLastDat,1,BLptN,"Bycatch_SE_Dat");
  BycatchLTrue_F.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchLTrue_F");
  BycatchLTrue_M.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchLTrue_M");
  BycatchLTrue_T.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchLTrue_T");
  BycatchLSDTrue_F.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchLSDTrue_F");
  BycatchLSDTrue_M.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchLSDTrue_M");
  BycatchLSDTrue_T.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchLSDTrue_T");
  BycatchWTrue_F.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchWTrue_F");
  BycatchWTrue_M.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchWTrue_M");
  BycatchWTrue_T.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"BycatchWTrue_T");
  CatchWt_Dat.allocate(YearFirstDat,YearLastDat,"CatchWt_Dat");
  DiscardWt_Dat.allocate(YearFirstDat,YearLastDat,"DiscardWt_Dat");
  BycatchWt_Dat.allocate(YearFirstDat,YearLastDat,"BycatchWt_Dat");
  SportCatchWt_Dat.allocate(YearFirstDat,YearLastDat,"SportCatchWt_Dat");
  PersUseWt_Dat.allocate(YearFirstDat,YearLastDat,"PersUseWt_Dat");
  TrueToSurf.allocate(1,AgePlusSurf,1,AgeTrueMaxDat,"TrueToSurf");
  TrueToBurn.allocate(1,AgePlusBurn,1,AgeTrueMaxDat,"TrueToBurn");
  PropMat.allocate(AgeMinDat,AgeTrueMaxDat,"PropMat");
  poplenage_F.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"poplenage_F");
  poplenage_M.allocate(YearFirstDat,YearLastDat,AgeTrueMinDat,AgeTrueMaxDat,"poplenage_M");
  ageSEscalar.allocate("ageSEscalar");
  survlenFLG.allocate("survlenFLG");
  age6SEscalar.allocate("age6SEscalar");
  survRSSmult.allocate("survRSSmult");
  DataCheck2.allocate("DataCheck2");
 if (DataCheck2 != -12345)
    {cerr << "Data are not in order." << endl; exit(1);} else
     cout << "Data are in order." << endl;
 Simulation = SimFlag;
		LastAge = AgeTrueMaxDat;
		FirstAgeDat = AgeMinDat;
		LastAgeDat = AgeMaxDat;
		SMinAge = FirstAgeDat;
		SMaxAge = LastAgeDat;
		CMinAge = 8;
  if (FirstYear <= 2001) AgePlusFirst = AgePlusSurf; else
                         AgePlusFirst = AgePlusBurn;
  TrueAgeFreqs.allocate(1,LastAge);
  ObsAgeFreqs.allocate(1,LastAgeDat);
  Catch.allocate(FirstYear,LastYear,SMinAge,SMaxAge,Sex1,Sex3);
  Catch_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  Catch_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  Catch_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  Catch_SE.allocate(FirstYear,LastYear,SMinAge,SMaxAge,Sex1,Sex3);
  Catch_SE_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  Catch_SE_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  Catch_SE_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  CCPUE.allocate(FirstYear,LastYear,SMinAge,SMaxAge,Sex1,Sex3);
  CCPUE_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  CCPUE_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  CCPUE_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  CCPUE_SE.allocate(FirstYear,LastYear,SMinAge,SMaxAge,Sex1,Sex3);
  CCPUE_SE_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  CCPUE_SE_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  CCPUE_SE_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvProp.allocate(FirstYear,LastYear,SMinAge,SMaxAge,Sex1,Sex3);
  SurvProp_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvProp_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvProp_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvProp_SE.allocate(FirstYear,LastYear,SMinAge,SMaxAge,Sex1,Sex3);
  SurvProp_SE_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvProp_SE_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvProp_SE_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvCPUE.allocate(FirstYear,LastYear,SMinAge,SMaxAge,Sex1,Sex3);
  SurvCPUE_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvCPUE_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvCPUE_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvCPUE_SE.allocate(FirstYear,LastYear,SMinAge,SMaxAge,Sex1,Sex3);
  SurvCPUE_SE_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvCPUE_SE_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  SurvCPUE_SE_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge);
  popw.allocate(YearFirstDat,YearLastDat,1,LastAge,Sex1,Sex3);
  popl.allocate(YearFirstDat,YearLastDat,1,LastAge,Sex1,Sex3);
  CatchWTrue.allocate(YearFirstDat,YearLastDat,1,LastAge,Sex1,Sex3);
  SurvL.allocate(YearFirstDat,YearLastDat,SMinAge,SMaxAge,Sex1,Sex3);
  SurvLTrue.allocate(YearFirstDat,YearLastDat,1,LastAge,Sex1,Sex3);
  SurvW.allocate(YearFirstDat,YearLastDat,SMinAge,SMaxAge,Sex1,Sex3);
  SurvWTrue.allocate(YearFirstDat,YearLastDat,1,LastAge,Sex1,Sex3);
  SurvPropLegal.allocate(YearFirstDat,YearLastDat,SMinAge,SMaxAge,Sex1,Sex3);
  SurvLegalW.allocate(YearFirstDat,YearLastDat,SMinAge,SMaxAge,Sex1,Sex3);
  BycatchLTrue.allocate(YearFirstDat,YearLastDat,1,LastAge,Sex1,Sex3);
  BycatchLSDTrue.allocate(YearFirstDat,YearLastDat,1,LastAge,Sex1,Sex3);
  BycatchWTrue.allocate(YearFirstDat,YearLastDat,1,LastAge,Sex1,Sex3);
 for (y=FirstYear; y<=LastYear; y++)
 for (a=SMinAge; a<=SMaxAge; a++)
   {
   Catch(y,a,1) = Catch_F_Dat(y,a);
   Catch(y,a,2) = Catch_M_Dat(y,a);
   Catch(y,a,3) = Catch_T_Dat(y,a);
   Catch_F(y,a) = Catch_F_Dat(y,a);
   Catch_M(y,a) = Catch_M_Dat(y,a);
   Catch_T(y,a) = Catch_T_Dat(y,a);
   Catch_SE(y,a,1) = Catch_SE_F_Dat(y,a);
   Catch_SE(y,a,2) = Catch_SE_M_Dat(y,a);
   Catch_SE(y,a,3) = Catch_SE_T_Dat(y,a);
   Catch_SE_F(y,a) = Catch_SE_F_Dat(y,a);
   Catch_SE_M(y,a) = Catch_SE_M_Dat(y,a);
   Catch_SE_T(y,a) = Catch_SE_T_Dat(y,a);
   if(y<=2001)
 {
   Catch_SE(y,a,1) = Catch_SE_F_Dat(y,a)*ageSEscalar;
   Catch_SE(y,a,2) = Catch_SE_M_Dat(y,a)*ageSEscalar;
   Catch_SE(y,a,3) = Catch_SE_T_Dat(y,a)*ageSEscalar;
   Catch_SE_F(y,a) = Catch_SE_F_Dat(y,a)*ageSEscalar;
   Catch_SE_M(y,a) = Catch_SE_M_Dat(y,a)*ageSEscalar;
   Catch_SE_T(y,a) = Catch_SE_T_Dat(y,a)*ageSEscalar;
 }
   if(a<=6)
 {
   Catch_SE(y,a,1) = Catch_SE_F_Dat(y,a)*age6SEscalar;
   Catch_SE(y,a,2) = Catch_SE_M_Dat(y,a)*age6SEscalar;
   Catch_SE(y,a,3) = Catch_SE_T_Dat(y,a)*age6SEscalar;
   Catch_SE_F(y,a) = Catch_SE_F_Dat(y,a)*age6SEscalar;
   Catch_SE_M(y,a) = Catch_SE_M_Dat(y,a)*age6SEscalar;
   Catch_SE_T(y,a) = Catch_SE_T_Dat(y,a)*age6SEscalar;
 }
   CCPUE(y,a,1) = CCPUE_F_Dat(y,a);
   CCPUE(y,a,2) = CCPUE_M_Dat(y,a);
   CCPUE(y,a,3) = CCPUE_T_Dat(y,a);
   CCPUE_F(y,a) = CCPUE_F_Dat(y,a);
   CCPUE_M(y,a) = CCPUE_M_Dat(y,a);
   CCPUE_T(y,a) = CCPUE_T_Dat(y,a);
   CCPUE_SE(y,a,1) = CCPUE_SE_F_Dat(y,a);
   CCPUE_SE(y,a,2) = CCPUE_SE_M_Dat(y,a);
   CCPUE_SE(y,a,3) = CCPUE_SE_T_Dat(y,a);
   CCPUE_SE_F(y,a) = CCPUE_SE_F_Dat(y,a);
   CCPUE_SE_M(y,a) = CCPUE_SE_M_Dat(y,a);
   CCPUE_SE_T(y,a) = CCPUE_SE_T_Dat(y,a);
   if(y<=2001)
 {
   CCPUE_SE(y,a,1) = CCPUE_SE_F_Dat(y,a)*ageSEscalar;
   CCPUE_SE(y,a,2) = CCPUE_SE_M_Dat(y,a)*ageSEscalar;
   CCPUE_SE(y,a,3) = CCPUE_SE_T_Dat(y,a)*ageSEscalar;
   CCPUE_SE_F(y,a) = CCPUE_SE_F_Dat(y,a)*ageSEscalar;
   CCPUE_SE_M(y,a) = CCPUE_SE_M_Dat(y,a)*ageSEscalar;
   CCPUE_SE_T(y,a) = CCPUE_SE_T_Dat(y,a)*ageSEscalar;
 }
   if(a<=6)
 {
   CCPUE_SE(y,a,1) = CCPUE_SE_F_Dat(y,a)*age6SEscalar;
   CCPUE_SE(y,a,2) = CCPUE_SE_M_Dat(y,a)*age6SEscalar;
   CCPUE_SE(y,a,3) = CCPUE_SE_T_Dat(y,a)*age6SEscalar;
   CCPUE_SE_F(y,a) = CCPUE_SE_F_Dat(y,a)*age6SEscalar;
   CCPUE_SE_M(y,a) = CCPUE_SE_M_Dat(y,a)*age6SEscalar;
   CCPUE_SE_T(y,a) = CCPUE_SE_T_Dat(y,a)*age6SEscalar;
 }
   SurvProp(y,a,1) = SurvProp_F_Dat(y,a);
   SurvProp(y,a,2) = SurvProp_M_Dat(y,a);
   SurvProp(y,a,3) = SurvProp_T_Dat(y,a);
   SurvProp_F(y,a) = SurvProp_F_Dat(y,a);
   SurvProp_M(y,a) = SurvProp_M_Dat(y,a);
   SurvProp_T(y,a) = SurvProp_T_Dat(y,a);
   SurvProp_SE(y,a,1) = SurvProp_SE_F_Dat(y,a);
   SurvProp_SE(y,a,2) = SurvProp_SE_M_Dat(y,a);
   SurvProp_SE(y,a,3) = SurvProp_SE_T_Dat(y,a);
   SurvProp_SE_F(y,a) = SurvProp_SE_F_Dat(y,a);
   SurvProp_SE_M(y,a) = SurvProp_SE_M_Dat(y,a);
   SurvProp_SE_T(y,a) = SurvProp_SE_T_Dat(y,a);
   if(y<=2001)
 {
   SurvProp_SE(y,a,1) = SurvProp_SE_F_Dat(y,a)*ageSEscalar;
   SurvProp_SE(y,a,2) = SurvProp_SE_M_Dat(y,a)*ageSEscalar;
   SurvProp_SE(y,a,3) = SurvProp_SE_T_Dat(y,a)*ageSEscalar;
   SurvProp_SE_F(y,a) = SurvProp_SE_F_Dat(y,a)*ageSEscalar;
   SurvProp_SE_M(y,a) = SurvProp_SE_M_Dat(y,a)*ageSEscalar;
   SurvProp_SE_T(y,a) = SurvProp_SE_T_Dat(y,a)*ageSEscalar;
 }
   if(a<=6)
 {
   SurvProp_SE(y,a,1) = SurvProp_SE_F_Dat(y,a)*age6SEscalar;
   SurvProp_SE(y,a,2) = SurvProp_SE_M_Dat(y,a)*age6SEscalar;
   SurvProp_SE(y,a,3) = SurvProp_SE_T_Dat(y,a)*age6SEscalar;
   SurvProp_SE_F(y,a) = SurvProp_SE_F_Dat(y,a)*age6SEscalar;
   SurvProp_SE_M(y,a) = SurvProp_SE_M_Dat(y,a)*age6SEscalar;
   SurvProp_SE_T(y,a) = SurvProp_SE_T_Dat(y,a)*age6SEscalar;
 }
   SurvCPUE(y,a,1) = SurvCPUE_F_Dat(y,a);
   SurvCPUE(y,a,2) = SurvCPUE_M_Dat(y,a);
   SurvCPUE(y,a,3) = SurvCPUE_T_Dat(y,a);
   SurvCPUE_F(y,a) = SurvCPUE_F_Dat(y,a);
   SurvCPUE_M(y,a) = SurvCPUE_M_Dat(y,a);
   SurvCPUE_T(y,a) = SurvCPUE_T_Dat(y,a);
   SurvCPUE_SE(y,a,1) = SurvCPUE_SE_F_Dat(y,a);
   SurvCPUE_SE(y,a,2) = SurvCPUE_SE_M_Dat(y,a);
   SurvCPUE_SE(y,a,3) = SurvCPUE_SE_T_Dat(y,a);
   SurvCPUE_SE_F(y,a) = SurvCPUE_SE_F_Dat(y,a);
   SurvCPUE_SE_M(y,a) = SurvCPUE_SE_M_Dat(y,a);
   SurvCPUE_SE_T(y,a) = SurvCPUE_SE_T_Dat(y,a);
   if(y<=2001)
 {
   SurvCPUE_SE(y,a,1) = SurvCPUE_SE_F_Dat(y,a)*ageSEscalar;
   SurvCPUE_SE(y,a,2) = SurvCPUE_SE_M_Dat(y,a)*ageSEscalar;
   SurvCPUE_SE(y,a,3) = SurvCPUE_SE_T_Dat(y,a)*ageSEscalar;
   SurvCPUE_SE_F(y,a) = SurvCPUE_SE_F_Dat(y,a)*ageSEscalar;
   SurvCPUE_SE_M(y,a) = SurvCPUE_SE_M_Dat(y,a)*ageSEscalar;
   SurvCPUE_SE_T(y,a) = SurvCPUE_SE_T_Dat(y,a)*ageSEscalar;
 }
   if(a<=6)
 {
   SurvCPUE_SE(y,a,1) = SurvCPUE_SE_F_Dat(y,a)*age6SEscalar;
   SurvCPUE_SE(y,a,2) = SurvCPUE_SE_M_Dat(y,a)*age6SEscalar;
   SurvCPUE_SE(y,a,3) = SurvCPUE_SE_T_Dat(y,a)*age6SEscalar;
   SurvCPUE_SE_F(y,a) = SurvCPUE_SE_F_Dat(y,a)*age6SEscalar;
   SurvCPUE_SE_M(y,a) = SurvCPUE_SE_M_Dat(y,a)*age6SEscalar;
   SurvCPUE_SE_T(y,a) = SurvCPUE_SE_T_Dat(y,a)*age6SEscalar;
 }
   }
 for (y=YearFirstDat; y<=YearLastDat; y++)
 for (a=SMinAge; a<=SMaxAge; a++)
   {  
   SurvL(y,a,1) = SurvL_F(y,a);
   SurvL(y,a,2) = SurvL_M(y,a);
   SurvL(y,a,3) = SurvL_T(y,a);
   SurvW(y,a,1) = SurvW_F(y,a);
   SurvW(y,a,2) = SurvW_M(y,a);
   SurvW(y,a,3) = SurvW_T(y,a);
   SurvPropLegal(y,a,1) = SurvPropLegal_F(y,a);
   SurvPropLegal(y,a,2) = SurvPropLegal_M(y,a);
   SurvPropLegal(y,a,3) = SurvPropLegal_T(y,a);
   SurvLegalW(y,a,1) = SurvLegalW_F(y,a);
   SurvLegalW(y,a,2) = SurvLegalW_M(y,a);
   SurvLegalW(y,a,3) = SurvLegalW_T(y,a);
   }
   for (y=YearFirstDat; y<=YearLastDat; y++)
   for (b=1; b<=LastAge; b++)
      {
      CatchWTrue(y,b,1) = CatchWTrue_F(y,b);
      CatchWTrue(y,b,2) = CatchWTrue_M(y,b);
      CatchWTrue(y,b,3) = CatchWTrue_T(y,b);
      SurvLTrue(y,b,1) = SurvLTrue_F(y,b);
      SurvLTrue(y,b,2) = SurvLTrue_M(y,b);
      SurvLTrue(y,b,3) = SurvLTrue_T(y,b);
      SurvWTrue(y,b,1) = SurvWTrue_F(y,b);
      SurvWTrue(y,b,2) = SurvWTrue_M(y,b);
      SurvWTrue(y,b,3) = SurvWTrue_T(y,b);
      BycatchLTrue(y,b,1) = BycatchLTrue_F(y,b);
      BycatchLTrue(y,b,2) = BycatchLTrue_M(y,b);
      BycatchLTrue(y,b,3) = BycatchLTrue_T(y,b);
      BycatchLSDTrue(y,b,1) = BycatchLSDTrue_F(y,b);
      BycatchLSDTrue(y,b,2) = BycatchLSDTrue_M(y,b);
      BycatchLSDTrue(y,b,3) = BycatchLSDTrue_T(y,b);
      BycatchWTrue(y,b,1) = BycatchWTrue_F(y,b);
      BycatchWTrue(y,b,2) = BycatchWTrue_M(y,b);
      BycatchWTrue(y,b,3) = BycatchWTrue_T(y,b);
   	  popw(y,b,1) = 0.00000691*pow(poplenage_F(y,b),3.24019356);
  	  popw(y,b,2) = 0.00000691*pow(poplenage_M(y,b),3.24019356);
  	  popw(y,b,3) = 0.00000691*pow(poplenage_F(y,b),3.24019356);
   	  popl(y,b,1) = poplenage_F(y,b);
  	  popl(y,b,2) = poplenage_M(y,b);
  	  popl(y,b,3) = poplenage_F(y,b);
      }
  Bycatch.allocate(FirstYear,LastYear,1,BLptN);
  Bycatch_SE.allocate(FirstYear,LastYear,1,BLptN);
	for (y=FirstYear; y<=LastYear; y++)
	for (v=1; v<=BLptN; v++)
	   {
	   Bycatch(y,v) = Bycatch_Dat(y,v);
	   Bycatch_SE(y,v) = Bycatch_SE_Dat(y,v);
	   }
  CCPUETot.allocate(FirstYear,LastYear);
  CCPUETot_SE.allocate(FirstYear,LastYear);
  CWPUETot.allocate(FirstYear,LastYear);
  CWPUETot_SE.allocate(FirstYear,LastYear);
  SurvCPUETot.allocate(FirstYear,LastYear);
  SurvCPUETot_SE.allocate(FirstYear,LastYear);
  SurvWPUETot.allocate(FirstYear,LastYear);
  SurvWPUETot_SE.allocate(FirstYear,LastYear);
  CatchWt.allocate(FirstYear,LastYear);
  DiscardWt.allocate(FirstYear,LastYear);
  BycatchWt.allocate(FirstYear,LastYear);
  SportCatchWt.allocate(FirstYear,LastYear);
  PersUseWt.allocate(FirstYear,LastYear);
   for (y=FirstYear; y<=LastYear; y++)
      {
      CCPUETot(y) = CCPUETot_Dat(y);
      CCPUETot_SE(y) = CCPUETot_SE_Dat(y);
      CWPUETot(y) = CWPUETot_Dat(y);
      CWPUETot_SE(y) = CWPUETot_SE_Dat(y);
      SurvCPUETot(y) = SurvCPUETot_Dat(y);
      SurvCPUETot_SE(y) = SurvCPUETot_SE_Dat(y);
      SurvWPUETot(y) = SurvWPUETot_Dat(y);
      SurvWPUETot_SE(y) = SurvWPUETot_SE_Dat(y);
      for (v=1; v<=BLptN; v++) Bycatch(y,v) = Bycatch_Dat(y,v);
      CatchWt(y) = CatchWt_Dat(y);
      DiscardWt(y) = DiscardWt_Dat(y);
      BycatchWt(y) = BycatchWt_Dat(y);
      SportCatchWt(y) = SportCatchWt_Dat(y);
      PersUseWt(y) = PersUseWt_Dat(y);
      }
  CatchN.allocate(FirstYear,LastYear);
  for (y=FirstYear; y<=LastYear; y++)
     {
     if (y<=2001) AgePlus = AgePlusSurf; else AgePlus = AgePlusBurn;
     CatchN(y) = 0.0;
     for (a=CMinAge; a<=AgePlus; a++) CatchN(y) += Catch_T(y,a);
     }
  LastSurvYear = 0;
  for (y=FirstYear; y<=SLastYearFit; y++)
     if (SurvCPUETot(y) != NA) LastSurvYear = y;
  LastYearClass = LastSurvYear - SMinAge;
  if (CLastYearFit - CMinAge > LastSurvYear - SMinAge)
      LastYearClass = CLastYearFit - CMinAge;
  vOne = 0;
  for (v=1; v<=SLptN; v++)
     if (SLptList(v)==SLptOne) vOne = v;
  if (SSelLForm==1) SSelLParN = SLptN - 2;
  if (SSelLForm==2) SSelLParN = SLptN - 1;
  if (SSelLForm==3) SSelLParN = vOne - 1;
  if (CSelLForm==1) CSelLParN = SLptN - 2;
  if (CSelLForm==2) CSelLParN = SLptN - 1;
  if (CSelLForm==3) CSelLParN = vOne - 1;
  BSelLParN = BLptN - 1;
  vOneB = 0;
  for (v=1; v<=BLptN; v++)
     if (BLptList(v)==BLptOne) vOneB = v;
  if (SmearAgesFlag==0)
     {
     TrueToSurf = TrueToSurf - TrueToSurf;
     for (a=1; a<=AgePlusSurf; a++) TrueToSurf(a,a) = 1.0;
     if (LastAge > AgePlusSurf)
        for (b=AgePlusSurf+1; b<=LastAge; b++) 
           TrueToSurf(AgePlusSurf,b) = 1.0;
     TrueToBurn = TrueToBurn - TrueToBurn;
     for (a=1; a<=AgePlusBurn; a++) TrueToBurn(a,a) = 1.0;
     if (LastAge > AgePlusBurn)
        for (b=AgePlusBurn+1; b<=LastAge; b++) 
           TrueToBurn(AgePlusBurn,b) = 1.0;
     }
  if (vOne==0)
     {cout << "SLptOne is not one of SLptList" << endl; exit(1);}
  if (SSelLParN<=0)
     {cout << "SSelLParN <= 0" << endl; exit(1);}
  if (vOneB==0)
     {cout << "BLptOne is not one of BLptList" << endl; exit(1);}
  if (CQEstYears(1) != FirstYear)
     {cerr << "CQ must be estimated in FirstYear" << endl; exit(1);}
  if (CSelLEstYears(1) != FirstYear)
     {cerr << "CSelL must be estimated in FirstYear" << endl; exit(1);}
  if (SQEstYears(1) != FirstYear)
     {cerr << "SQ must be estimated in FirstYear" << endl; exit(1);}
  if (SSelLEstYears(1) != FirstYear)
     {cerr << "SSelL must be estimated in FirstYear" << endl; exit(1);}
  if (BSelLEstYears(1) != FirstYear)
     {cerr << "BSelL must be estimated in FirstYear" << endl; exit(1);}
  for (w=1; w<=CQEstN; w++)
     if (CQEstYears(w)==1983)
        {cerr << "CQ cannot be estimated in 1983" << endl; exit(1);}
  if (CLastYearFit < FirstYear || CLastYearFit > LastYear)
    {cerr << "CLastYearFit out of range" << endl; exit(1);}
  if (SLastYearFit < FirstYear || SLastYearFit > LastYear)
    {cerr << "SLastYearFit out of range" << endl; exit(1);}
  if (LastYearClass < FirstYear)
    {cerr << "LastYearClass < FirstYear" << endl; exit(1);}
  if (FitBycatchNosFlag == 0) 
        {
        P_BSelLX = -1; 
        FitBycatchWtFlag = 1;
        } else
        {
        P_BSelLX = 1;
        FitBycatchWtFlag = 0;
        }
 if (EstMFlag != 0) PM = 1; else PM = -1;
 if (EstMMFlag != 0) PMM = 1; else PMM = -1;
 if (SplitMalesFlag == 1) P_QMX = 1; else P_QMX = -1;
 if (SplitMalesFlag == 1) P_SelL_M = 1; else P_SelL_M = -1;
 if (RobustifyFlag != 0) P_ProForma = 2; else P_ProForma = 1;
}

model_parameters::model_parameters(int sz,int argc,char * argv[]) : 
 model_data(argc,argv) , function_minimizer(sz)
{
  initializationfunction();
  MinusLogL.allocate("MinusLogL");
  Deviance.allocate("Deviance");
  #ifndef NO_AD_INITIALIZE
  Deviance.initialize();
  #endif
  SSTotal.allocate("SSTotal");
  #ifndef NO_AD_INITIALIZE
  SSTotal.initialize();
  #endif
  RSSTotal.allocate("RSSTotal");
  #ifndef NO_AD_INITIALIZE
  RSSTotal.initialize();
  #endif
  RSSNobs.allocate("RSSNobs");
  #ifndef NO_AD_INITIALIZE
  RSSNobs.initialize();
  #endif
  PSSTotal.allocate("PSSTotal");
  #ifndef NO_AD_INITIALIZE
  PSSTotal.initialize();
  #endif
  M.allocate(FirstYear,LastYear,Sex1,Sex2,"M");
  #ifndef NO_AD_INITIALIZE
    M.initialize();
  #endif
  MPar.allocate(0.05,0.25,PM,"MPar");
  MPar_M.allocate(0.05,0.25,PMM,"MPar_M");
  CF.allocate(FirstYear,LastYear,Sex1,Sex2,"CF");
  #ifndef NO_AD_INITIALIZE
    CF.initialize();
  #endif
  CFPar.allocate(FirstYear,LastYear,CFParMin,CFParMax,"CFPar");
  CQ.allocate(FirstYear,LastYear,Sex1,Sex2,"CQ");
  #ifndef NO_AD_INITIALIZE
    CQ.initialize();
  #endif
  CQEstPar.allocate(1,CQEstN,1.0E-2,1.0E2,"CQEstPar");
  CQEst.allocate(1,CQEstN,"CQEst");
  #ifndef NO_AD_INITIALIZE
    CQEst.initialize();
  #endif
  CQMX.allocate(0.1,10.0,P_QMX,"CQMX");
 if (SplitMalesFlag == 0) CQMX = 1.0; // GOOD_COP.
  StartVal.allocate("StartVal");
  #ifndef NO_AD_INITIALIZE
  StartVal.initialize();
  #endif
  StopVal.allocate("StopVal");
  #ifndef NO_AD_INITIALIZE
  StopVal.initialize();
  #endif
  StepVal.allocate("StepVal");
  #ifndef NO_AD_INITIALIZE
  StepVal.initialize();
  #endif
  PathLength.allocate("PathLength");
  #ifndef NO_AD_INITIALIZE
  PathLength.initialize();
  #endif
  CSelL.allocate(FirstYear,LastYear,1,SLptN,Sex1,Sex2,"CSelL");
  #ifndef NO_AD_INITIALIZE
    CSelL.initialize();
  #endif
  CSelL_F.allocate(FirstYear,LastYear,1,SLptN,"CSelL_F");
  #ifndef NO_AD_INITIALIZE
    CSelL_F.initialize();
  #endif
  CSelL_M.allocate(FirstYear,LastYear,1,SLptN,"CSelL_M");
  #ifndef NO_AD_INITIALIZE
    CSelL_M.initialize();
  #endif
  CSelLy.allocate(Sex1,Sex2,1,SLptN,"CSelLy");
  #ifndef NO_AD_INITIALIZE
    CSelLy.initialize();
  #endif
  CSelLPar.allocate(1,CSelLEstN,1,CSelLParN,0.0,1.0,"CSelLPar");
  CSelLPar_M.allocate(1,CSelLEstN,1,CSelLParN,0.0,1.0,P_SelL_M,"CSelLPar_M");
  CSelLParSplit.allocate(1,CSelLEstN,1,CSelLParN,Sex1,Sex2,"CSelLParSplit");
  #ifndef NO_AD_INITIALIZE
    CSelLParSplit.initialize();
  #endif
  CSelLEst.allocate(1,CSelLEstN,1,SLptN,Sex1,Sex2,"CSelLEst");
  #ifndef NO_AD_INITIALIZE
    CSelLEst.initialize();
  #endif
  CSel.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"CSel");
  #ifndef NO_AD_INITIALIZE
    CSel.initialize();
  #endif
  CSel_F.allocate(FirstYear,LastYear,1,LastAge,"CSel_F");
  #ifndef NO_AD_INITIALIZE
    CSel_F.initialize();
  #endif
  CSel_M.allocate(FirstYear,LastYear,1,LastAge,"CSel_M");
  #ifndef NO_AD_INITIALIZE
    CSel_M.initialize();
  #endif
  FSel.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"FSel");
  #ifndef NO_AD_INITIALIZE
    FSel.initialize();
  #endif
  FSel_F.allocate(FirstYear,LastYear,1,LastAge,"FSel_F");
  #ifndef NO_AD_INITIALIZE
    FSel_F.initialize();
  #endif
  FSel_M.allocate(FirstYear,LastYear,1,LastAge,"FSel_M");
  #ifndef NO_AD_INITIALIZE
    FSel_M.initialize();
  #endif
  DF.allocate(FirstYear,LastYear,"DF");
  #ifndef NO_AD_INITIALIZE
    DF.initialize();
  #endif
  DFPar.allocate(FirstYear,LastYear,0.0,0.1,"DFPar");
  DSelL.allocate(1,SLptN,"DSelL");
  #ifndef NO_AD_INITIALIZE
    DSelL.initialize();
  #endif
 for (v=1; v<=SLptN; v++)
    {if  (SLptList(v)==80) DSelL(v) = 1.0; else DSelL(v) = 0.0;}
  DSel.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"DSel");
  #ifndef NO_AD_INITIALIZE
    DSel.initialize();
  #endif
  DSel_F.allocate(FirstYear,LastYear,1,LastAge,"DSel_F");
  #ifndef NO_AD_INITIALIZE
    DSel_F.initialize();
  #endif
  DSel_M.allocate(FirstYear,LastYear,1,LastAge,"DSel_M");
  #ifndef NO_AD_INITIALIZE
    DSel_M.initialize();
  #endif
  SQ.allocate(FirstYear,LastYear,Sex1,Sex2,"SQ");
  #ifndef NO_AD_INITIALIZE
    SQ.initialize();
  #endif
  SQEstPar.allocate(1,SQEstN,1.0E-2,1.0E2,"SQEstPar");
  SQEst.allocate(1,SQEstN,"SQEst");
  #ifndef NO_AD_INITIALIZE
    SQEst.initialize();
  #endif
  SQMX.allocate(0.1,10.0,P_QMX,"SQMX");
 if (SplitMalesFlag == 0) SQMX = 1.0; // GOOD_COP.
  SQ_bhat.allocate("SQ_bhat");
  #ifndef NO_AD_INITIALIZE
  SQ_bhat.initialize();
  #endif
  SSelL.allocate(FirstYear,LastYear,1,SLptN,Sex1,Sex2,"SSelL");
  #ifndef NO_AD_INITIALIZE
    SSelL.initialize();
  #endif
  SSelL_F.allocate(FirstYear,LastYear,1,SLptN,"SSelL_F");
  #ifndef NO_AD_INITIALIZE
    SSelL_F.initialize();
  #endif
  SSelL_M.allocate(FirstYear,LastYear,1,SLptN,"SSelL_M");
  #ifndef NO_AD_INITIALIZE
    SSelL_M.initialize();
  #endif
  SSelLy.allocate(Sex1,Sex2,1,SLptN,"SSelLy");
  #ifndef NO_AD_INITIALIZE
    SSelLy.initialize();
  #endif
  SSelLPar.allocate(1,SSelLEstN,1,SSelLParN,0.0,1.0,"SSelLPar");
  SSelLPar_M.allocate(1,SSelLEstN,1,SSelLParN,0.0,1.0,P_SelL_M,"SSelLPar_M");
  SSelLParSplit.allocate(1,SSelLEstN,1,SSelLParN,Sex1,Sex2,"SSelLParSplit");
  #ifndef NO_AD_INITIALIZE
    SSelLParSplit.initialize();
  #endif
  SSelLEst.allocate(1,SSelLEstN,1,SLptN,Sex1,Sex2,"SSelLEst");
  #ifndef NO_AD_INITIALIZE
    SSelLEst.initialize();
  #endif
  StartVec.allocate(1,SLptN,"StartVec");
  #ifndef NO_AD_INITIALIZE
    StartVec.initialize();
  #endif
  StopVec.allocate(1,SLptN,"StopVec");
  #ifndef NO_AD_INITIALIZE
    StopVec.initialize();
  #endif
  StepVec.allocate(1,SLptN,"StepVec");
  #ifndef NO_AD_INITIALIZE
    StepVec.initialize();
  #endif
  SelVec.allocate(1,SLptN,"SelVec");
  #ifndef NO_AD_INITIALIZE
    SelVec.initialize();
  #endif
  SSel.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"SSel");
  #ifndef NO_AD_INITIALIZE
    SSel.initialize();
  #endif
  SSel_F.allocate(FirstYear,LastYear,1,LastAge,"SSel_F");
  #ifndef NO_AD_INITIALIZE
    SSel_F.initialize();
  #endif
  SSel_M.allocate(FirstYear,LastYear,1,LastAge,"SSel_M");
  #ifndef NO_AD_INITIALIZE
    SSel_M.initialize();
  #endif
  BF.allocate(FirstYear,LastYear,0.0,1.0,"BF");
  BSelL.allocate(FirstYear,LastYear,1,BLptN,Sex1,Sex2,"BSelL");
  #ifndef NO_AD_INITIALIZE
    BSelL.initialize();
  #endif
  BSelL_F.allocate(FirstYear,LastYear,1,BLptN,"BSelL_F");
  #ifndef NO_AD_INITIALIZE
    BSelL_F.initialize();
  #endif
  BSelL_M.allocate(FirstYear,LastYear,1,BLptN,"BSelL_M");
  #ifndef NO_AD_INITIALIZE
    BSelL_M.initialize();
  #endif
  BSelLy.allocate(Sex1,Sex2,1,BLptN,"BSelLy");
  #ifndef NO_AD_INITIALIZE
    BSelLy.initialize();
  #endif
  BSelLPar.allocate(1,BSelLEstN,1,BSelLParN,0.001,1000.0,P_BSelLX,"BSelLPar");
  BSelLEst.allocate(1,BSelLEstN,1,BLptN,"BSelLEst");
  #ifndef NO_AD_INITIALIZE
    BSelLEst.initialize();
  #endif
  BSel.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"BSel");
  #ifndef NO_AD_INITIALIZE
    BSel.initialize();
  #endif
  BSel_F.allocate(FirstYear,LastYear,1,LastAge,"BSel_F");
  #ifndef NO_AD_INITIALIZE
    BSel_F.initialize();
  #endif
  BSel_M.allocate(FirstYear,LastYear,1,LastAge,"BSel_M");
  #ifndef NO_AD_INITIALIZE
    BSel_M.initialize();
  #endif
  StartVecB.allocate(1,BLptN,"StartVecB");
  #ifndef NO_AD_INITIALIZE
    StartVecB.initialize();
  #endif
  StopVecB.allocate(1,BLptN,"StopVecB");
  #ifndef NO_AD_INITIALIZE
    StopVecB.initialize();
  #endif
  StepVecB.allocate(1,BLptN,"StepVecB");
  #ifndef NO_AD_INITIALIZE
    StepVecB.initialize();
  #endif
  RFPar.allocate(FirstYear,LastYear,0.0,1.0,"RFPar");
  RF.allocate(FirstYear,LastYear,Sex1,Sex2,"RF");
  #ifndef NO_AD_INITIALIZE
    RF.initialize();
  #endif
  RSel.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"RSel");
  #ifndef NO_AD_INITIALIZE
    RSel.initialize();
  #endif
  PFPar.allocate(FirstYear,LastYear,0.0,1.0,"PFPar");
  PF.allocate(FirstYear,LastYear,Sex1,Sex2,"PF");
  #ifndef NO_AD_INITIALIZE
    PF.initialize();
  #endif
  PSel.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"PSel");
  #ifndef NO_AD_INITIALIZE
    PSel.initialize();
  #endif
  OldZ.allocate(Sex1,Sex2,"OldZ");
  #ifndef NO_AD_INITIALIZE
    OldZ.initialize();
  #endif
  Cf.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"Cf");
  #ifndef NO_AD_INITIALIZE
    Cf.initialize();
  #endif
  Df.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"Df");
  #ifndef NO_AD_INITIALIZE
    Df.initialize();
  #endif
  Bf.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"Bf");
  #ifndef NO_AD_INITIALIZE
    Bf.initialize();
  #endif
  Rf.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"Rf");
  #ifndef NO_AD_INITIALIZE
    Rf.initialize();
  #endif
  Pf.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"Pf");
  #ifndef NO_AD_INITIALIZE
    Pf.initialize();
  #endif
  Z.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex2,"Z");
  #ifndef NO_AD_INITIALIZE
    Z.initialize();
  #endif
  Z_F.allocate(FirstYear,LastYear,1,LastAge,"Z_F");
  #ifndef NO_AD_INITIALIZE
    Z_F.initialize();
  #endif
  Z_M.allocate(FirstYear,LastYear,1,LastAge,"Z_M");
  #ifndef NO_AD_INITIALIZE
    Z_M.initialize();
  #endif
  N.allocate(FirstYear,LastYear+1,1,LastAge,Sex1,Sex3,"N");
  #ifndef NO_AD_INITIALIZE
    N.initialize();
  #endif
  N_F.allocate(FirstYear,LastYear+1,1,LastAge,"N_F");
  #ifndef NO_AD_INITIALIZE
    N_F.initialize();
  #endif
  N_M.allocate(FirstYear,LastYear+1,1,LastAge,"N_M");
  #ifndef NO_AD_INITIALIZE
    N_M.initialize();
  #endif
  N_T.allocate(FirstYear,LastYear+1,1,LastAge,"N_T");
  #ifndef NO_AD_INITIALIZE
    N_T.initialize();
  #endif
  NBar.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex3,"NBar");
  #ifndef NO_AD_INITIALIZE
    NBar.initialize();
  #endif
  NBar_F.allocate(FirstYear,LastYear,1,LastAge,"NBar_F");
  #ifndef NO_AD_INITIALIZE
    NBar_F.initialize();
  #endif
  NBar_M.allocate(FirstYear,LastYear,1,LastAge,"NBar_M");
  #ifndef NO_AD_INITIALIZE
    NBar_M.initialize();
  #endif
  NBar_T.allocate(FirstYear,LastYear,1,LastAge,"NBar_T");
  #ifndef NO_AD_INITIALIZE
    NBar_T.initialize();
  #endif
  CEN.allocate(FirstYear,LastYear+1,1,LastAge,Sex1,Sex3,"CEN");
  #ifndef NO_AD_INITIALIZE
    CEN.initialize();
  #endif
  CEN_F.allocate(FirstYear,LastYear+1,1,LastAge,"CEN_F");
  #ifndef NO_AD_INITIALIZE
    CEN_F.initialize();
  #endif
  CEN_M.allocate(FirstYear,LastYear+1,1,LastAge,"CEN_M");
  #ifndef NO_AD_INITIALIZE
    CEN_M.initialize();
  #endif
  CEN_T.allocate(FirstYear,LastYear+1,1,LastAge,"CEN_T");
  #ifndef NO_AD_INITIALIZE
    CEN_T.initialize();
  #endif
  FEN.allocate(FirstYear,LastYear+1,1,LastAge,Sex1,Sex3,"FEN");
  #ifndef NO_AD_INITIALIZE
    FEN.initialize();
  #endif
  FEN_F.allocate(FirstYear,LastYear+1,1,LastAge,"FEN_F");
  #ifndef NO_AD_INITIALIZE
    FEN_F.initialize();
  #endif
  FEN_M.allocate(FirstYear,LastYear+1,1,LastAge,"FEN_M");
  #ifndef NO_AD_INITIALIZE
    FEN_M.initialize();
  #endif
  FEN_T.allocate(FirstYear,LastYear+1,1,LastAge,"FEN_T");
  #ifndef NO_AD_INITIALIZE
    FEN_T.initialize();
  #endif
  SEN.allocate(FirstYear,LastYear+1,1,LastAge,Sex1,Sex3,"SEN");
  #ifndef NO_AD_INITIALIZE
    SEN.initialize();
  #endif
  SEN_F.allocate(FirstYear,LastYear+1,1,LastAge,"SEN_F");
  #ifndef NO_AD_INITIALIZE
    SEN_F.initialize();
  #endif
  SEN_M.allocate(FirstYear,LastYear+1,1,LastAge,"SEN_M");
  #ifndef NO_AD_INITIALIZE
    SEN_M.initialize();
  #endif
  SEN_T.allocate(FirstYear,LastYear+1,1,LastAge,"SEN_T");
  #ifndef NO_AD_INITIALIZE
    SEN_T.initialize();
  #endif
  InitN.allocate(2,LastAge,Sex1,Sex3,"InitN");
  #ifndef NO_AD_INITIALIZE
    InitN.initialize();
  #endif
  InitNSeenPar.allocate(2,AgePlusFirst,Sex1,Sex2,0.0,RMMax,"InitNSeenPar");
  InitNSeen.allocate(2,AgePlusFirst,Sex1,Sex2,"InitNSeen");
  #ifndef NO_AD_INITIALIZE
    InitNSeen.initialize();
  #endif
  R.allocate(FirstYear,LastYear+1,Sex1,Sex3,"R");
  #ifndef NO_AD_INITIALIZE
    R.initialize();
  #endif
  RSeenPar.allocate(FirstYear,LastYearClass+1,0.0,RMMax,"RSeenPar");
  PropFem.allocate(0.4,0.6,-1,"PropFem");
  RSeen.allocate(FirstYear,LastYearClass+1,"RSeen");
  #ifndef NO_AD_INITIALIZE
    RSeen.initialize();
  #endif
  RMean.allocate("RMean");
  #ifndef NO_AD_INITIALIZE
  RMean.initialize();
  #endif
  ProForma.allocate(P_ProForma,"ProForma");
  ParamCheck.allocate(-1,"ParamCheck");
 if (ParamCheck != CheckValue)
     {
     cerr << "Parameters are not in order." << endl;
     cerr << "Check value is " << ParamCheck << endl;
     exit(1);
     } else
     cout << "Parameters are in order." << endl;
  NS_F.allocate(FirstYear,LastYear+1,SMinAge,SMaxAge,"NS_F");
  #ifndef NO_AD_INITIALIZE
    NS_F.initialize();
  #endif
  NS_M.allocate(FirstYear,LastYear+1,SMinAge,SMaxAge,"NS_M");
  #ifndef NO_AD_INITIALIZE
    NS_M.initialize();
  #endif
  CENS_F.allocate(FirstYear,LastYear+1,SMinAge,SMaxAge,"CENS_F");
  #ifndef NO_AD_INITIALIZE
    CENS_F.initialize();
  #endif
  CENS_M.allocate(FirstYear,LastYear+1,SMinAge,SMaxAge,"CENS_M");
  #ifndef NO_AD_INITIALIZE
    CENS_M.initialize();
  #endif
  FENS_F.allocate(FirstYear,LastYear+1,SMinAge,SMaxAge,"FENS_F");
  #ifndef NO_AD_INITIALIZE
    FENS_F.initialize();
  #endif
  FENS_M.allocate(FirstYear,LastYear+1,SMinAge,SMaxAge,"FENS_M");
  #ifndef NO_AD_INITIALIZE
    FENS_M.initialize();
  #endif
  SENS_F.allocate(FirstYear,LastYear+1,SMinAge,SMaxAge,"SENS_F");
  #ifndef NO_AD_INITIALIZE
    SENS_F.initialize();
  #endif
  SENS_M.allocate(FirstYear,LastYear+1,SMinAge,SMaxAge,"SENS_M");
  #ifndef NO_AD_INITIALIZE
    SENS_M.initialize();
  #endif
  Catch_Pred_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"Catch_Pred_F");
  #ifndef NO_AD_INITIALIZE
    Catch_Pred_F.initialize();
  #endif
  Catch_Pred_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"Catch_Pred_M");
  #ifndef NO_AD_INITIALIZE
    Catch_Pred_M.initialize();
  #endif
  Catch_Pred_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"Catch_Pred_T");
  #ifndef NO_AD_INITIALIZE
    Catch_Pred_T.initialize();
  #endif
  Catch_RSS.allocate("Catch_RSS");
  #ifndef NO_AD_INITIALIZE
  Catch_RSS.initialize();
  #endif
  Catch_RSS_F.allocate("Catch_RSS_F");
  #ifndef NO_AD_INITIALIZE
  Catch_RSS_F.initialize();
  #endif
  Catch_RSS_M.allocate("Catch_RSS_M");
  #ifndef NO_AD_INITIALIZE
  Catch_RSS_M.initialize();
  #endif
  Catch_RSS_T.allocate("Catch_RSS_T");
  #ifndef NO_AD_INITIALIZE
  Catch_RSS_T.initialize();
  #endif
  Catch_n.allocate("Catch_n");
  #ifndef NO_AD_INITIALIZE
  Catch_n.initialize();
  #endif
  Catch_n_F.allocate("Catch_n_F");
  #ifndef NO_AD_INITIALIZE
  Catch_n_F.initialize();
  #endif
  Catch_n_M.allocate("Catch_n_M");
  #ifndef NO_AD_INITIALIZE
  Catch_n_M.initialize();
  #endif
  Catch_n_T.allocate("Catch_n_T");
  #ifndef NO_AD_INITIALIZE
  Catch_n_T.initialize();
  #endif
  Catch_rms.allocate("Catch_rms");
  #ifndef NO_AD_INITIALIZE
  Catch_rms.initialize();
  #endif
  Catch_rms_F.allocate("Catch_rms_F");
  #ifndef NO_AD_INITIALIZE
  Catch_rms_F.initialize();
  #endif
  Catch_rms_M.allocate("Catch_rms_M");
  #ifndef NO_AD_INITIALIZE
  Catch_rms_M.initialize();
  #endif
  Catch_rms_T.allocate("Catch_rms_T");
  #ifndef NO_AD_INITIALIZE
  Catch_rms_T.initialize();
  #endif
  RSS_list.allocate(1,3,"RSS_list");
  #ifndef NO_AD_INITIALIZE
    RSS_list.initialize();
  #endif
  CCPUE_Pred_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"CCPUE_Pred_F");
  #ifndef NO_AD_INITIALIZE
    CCPUE_Pred_F.initialize();
  #endif
  CCPUE_Pred_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"CCPUE_Pred_M");
  #ifndef NO_AD_INITIALIZE
    CCPUE_Pred_M.initialize();
  #endif
  CCPUE_Pred_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"CCPUE_Pred_T");
  #ifndef NO_AD_INITIALIZE
    CCPUE_Pred_T.initialize();
  #endif
  CCPUE_RSS.allocate("CCPUE_RSS");
  #ifndef NO_AD_INITIALIZE
  CCPUE_RSS.initialize();
  #endif
  CCPUE_RSS_F.allocate("CCPUE_RSS_F");
  #ifndef NO_AD_INITIALIZE
  CCPUE_RSS_F.initialize();
  #endif
  CCPUE_RSS_M.allocate("CCPUE_RSS_M");
  #ifndef NO_AD_INITIALIZE
  CCPUE_RSS_M.initialize();
  #endif
  CCPUE_RSS_T.allocate("CCPUE_RSS_T");
  #ifndef NO_AD_INITIALIZE
  CCPUE_RSS_T.initialize();
  #endif
  CCPUE_n.allocate("CCPUE_n");
  #ifndef NO_AD_INITIALIZE
  CCPUE_n.initialize();
  #endif
  CCPUE_n_F.allocate("CCPUE_n_F");
  #ifndef NO_AD_INITIALIZE
  CCPUE_n_F.initialize();
  #endif
  CCPUE_n_M.allocate("CCPUE_n_M");
  #ifndef NO_AD_INITIALIZE
  CCPUE_n_M.initialize();
  #endif
  CCPUE_n_T.allocate("CCPUE_n_T");
  #ifndef NO_AD_INITIALIZE
  CCPUE_n_T.initialize();
  #endif
  CCPUE_rms.allocate("CCPUE_rms");
  #ifndef NO_AD_INITIALIZE
  CCPUE_rms.initialize();
  #endif
  CCPUE_rms_F.allocate("CCPUE_rms_F");
  #ifndef NO_AD_INITIALIZE
  CCPUE_rms_F.initialize();
  #endif
  CCPUE_rms_M.allocate("CCPUE_rms_M");
  #ifndef NO_AD_INITIALIZE
  CCPUE_rms_M.initialize();
  #endif
  CCPUE_rms_T.allocate("CCPUE_rms_T");
  #ifndef NO_AD_INITIALIZE
  CCPUE_rms_T.initialize();
  #endif
  CCPUETot_Pred.allocate(FirstYear,LastYear,"CCPUETot_Pred");
  #ifndef NO_AD_INITIALIZE
    CCPUETot_Pred.initialize();
  #endif
  CCPUETot_RSS.allocate("CCPUETot_RSS");
  #ifndef NO_AD_INITIALIZE
  CCPUETot_RSS.initialize();
  #endif
  CCPUETot_n.allocate("CCPUETot_n");
  #ifndef NO_AD_INITIALIZE
  CCPUETot_n.initialize();
  #endif
  CCPUETot_rms.allocate("CCPUETot_rms");
  #ifndef NO_AD_INITIALIZE
  CCPUETot_rms.initialize();
  #endif
  CWPUETot_Pred.allocate(FirstYear,LastYear,"CWPUETot_Pred");
  #ifndef NO_AD_INITIALIZE
    CWPUETot_Pred.initialize();
  #endif
  CWPUETot_RSS.allocate("CWPUETot_RSS");
  #ifndef NO_AD_INITIALIZE
  CWPUETot_RSS.initialize();
  #endif
  CWPUETot_n.allocate("CWPUETot_n");
  #ifndef NO_AD_INITIALIZE
  CWPUETot_n.initialize();
  #endif
  CWPUETot_rms.allocate("CWPUETot_rms");
  #ifndef NO_AD_INITIALIZE
  CWPUETot_rms.initialize();
  #endif
  SurvProp_Pred_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SurvProp_Pred_F");
  #ifndef NO_AD_INITIALIZE
    SurvProp_Pred_F.initialize();
  #endif
  SurvProp_Pred_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SurvProp_Pred_M");
  #ifndef NO_AD_INITIALIZE
    SurvProp_Pred_M.initialize();
  #endif
  SurvProp_Pred_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SurvProp_Pred_T");
  #ifndef NO_AD_INITIALIZE
    SurvProp_Pred_T.initialize();
  #endif
  SurvProp_RSS.allocate("SurvProp_RSS");
  #ifndef NO_AD_INITIALIZE
  SurvProp_RSS.initialize();
  #endif
  SurvProp_RSS_F.allocate("SurvProp_RSS_F");
  #ifndef NO_AD_INITIALIZE
  SurvProp_RSS_F.initialize();
  #endif
  SurvProp_RSS_M.allocate("SurvProp_RSS_M");
  #ifndef NO_AD_INITIALIZE
  SurvProp_RSS_M.initialize();
  #endif
  SurvProp_RSS_T.allocate("SurvProp_RSS_T");
  #ifndef NO_AD_INITIALIZE
  SurvProp_RSS_T.initialize();
  #endif
  SurvProp_n.allocate("SurvProp_n");
  #ifndef NO_AD_INITIALIZE
  SurvProp_n.initialize();
  #endif
  SurvProp_n_F.allocate("SurvProp_n_F");
  #ifndef NO_AD_INITIALIZE
  SurvProp_n_F.initialize();
  #endif
  SurvProp_n_M.allocate("SurvProp_n_M");
  #ifndef NO_AD_INITIALIZE
  SurvProp_n_M.initialize();
  #endif
  SurvProp_n_T.allocate("SurvProp_n_T");
  #ifndef NO_AD_INITIALIZE
  SurvProp_n_T.initialize();
  #endif
  SurvProp_rms.allocate("SurvProp_rms");
  #ifndef NO_AD_INITIALIZE
  SurvProp_rms.initialize();
  #endif
  SurvProp_rms_F.allocate("SurvProp_rms_F");
  #ifndef NO_AD_INITIALIZE
  SurvProp_rms_F.initialize();
  #endif
  SurvProp_rms_M.allocate("SurvProp_rms_M");
  #ifndef NO_AD_INITIALIZE
  SurvProp_rms_M.initialize();
  #endif
  SurvProp_rms_T.allocate("SurvProp_rms_T");
  #ifndef NO_AD_INITIALIZE
  SurvProp_rms_T.initialize();
  #endif
  SurvCPUE_Pred_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SurvCPUE_Pred_F");
  #ifndef NO_AD_INITIALIZE
    SurvCPUE_Pred_F.initialize();
  #endif
  SurvCPUE_Pred_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SurvCPUE_Pred_M");
  #ifndef NO_AD_INITIALIZE
    SurvCPUE_Pred_M.initialize();
  #endif
  SurvCPUE_Pred_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SurvCPUE_Pred_T");
  #ifndef NO_AD_INITIALIZE
    SurvCPUE_Pred_T.initialize();
  #endif
  SurvCPUE_RSS.allocate("SurvCPUE_RSS");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_RSS.initialize();
  #endif
  SurvCPUE_RSS_F.allocate("SurvCPUE_RSS_F");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_RSS_F.initialize();
  #endif
  SurvCPUE_RSS_M.allocate("SurvCPUE_RSS_M");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_RSS_M.initialize();
  #endif
  SurvCPUE_RSS_T.allocate("SurvCPUE_RSS_T");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_RSS_T.initialize();
  #endif
  SurvCPUE_n.allocate("SurvCPUE_n");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_n.initialize();
  #endif
  SurvCPUE_n_F.allocate("SurvCPUE_n_F");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_n_F.initialize();
  #endif
  SurvCPUE_n_M.allocate("SurvCPUE_n_M");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_n_M.initialize();
  #endif
  SurvCPUE_n_T.allocate("SurvCPUE_n_T");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_n_T.initialize();
  #endif
  SurvCPUE_rms.allocate("SurvCPUE_rms");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_rms.initialize();
  #endif
  SurvCPUE_rms_F.allocate("SurvCPUE_rms_F");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_rms_F.initialize();
  #endif
  SurvCPUE_rms_M.allocate("SurvCPUE_rms_M");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_rms_M.initialize();
  #endif
  SurvCPUE_rms_T.allocate("SurvCPUE_rms_T");
  #ifndef NO_AD_INITIALIZE
  SurvCPUE_rms_T.initialize();
  #endif
  SurvCPUETot_Pred.allocate(FirstYear,LastYear,"SurvCPUETot_Pred");
  #ifndef NO_AD_INITIALIZE
    SurvCPUETot_Pred.initialize();
  #endif
  SurvCPUETot_RSS.allocate("SurvCPUETot_RSS");
  #ifndef NO_AD_INITIALIZE
  SurvCPUETot_RSS.initialize();
  #endif
  SurvCPUETot_n.allocate("SurvCPUETot_n");
  #ifndef NO_AD_INITIALIZE
  SurvCPUETot_n.initialize();
  #endif
  SurvCPUETot_rms.allocate("SurvCPUETot_rms");
  #ifndef NO_AD_INITIALIZE
  SurvCPUETot_rms.initialize();
  #endif
  SurvWPUETot_Pred.allocate(FirstYear,LastYear,"SurvWPUETot_Pred");
  #ifndef NO_AD_INITIALIZE
    SurvWPUETot_Pred.initialize();
  #endif
  SurvWPUETot_RSS.allocate("SurvWPUETot_RSS");
  #ifndef NO_AD_INITIALIZE
  SurvWPUETot_RSS.initialize();
  #endif
  SurvWPUETot_n.allocate("SurvWPUETot_n");
  #ifndef NO_AD_INITIALIZE
  SurvWPUETot_n.initialize();
  #endif
  SurvWPUETot_rms.allocate("SurvWPUETot_rms");
  #ifndef NO_AD_INITIALIZE
  SurvWPUETot_rms.initialize();
  #endif
  DiscardWt_Pred.allocate(FirstYear,LastYear,"DiscardWt_Pred");
  #ifndef NO_AD_INITIALIZE
    DiscardWt_Pred.initialize();
  #endif
  DiscardWt_RSS.allocate("DiscardWt_RSS");
  #ifndef NO_AD_INITIALIZE
  DiscardWt_RSS.initialize();
  #endif
  DiscardWt_n.allocate("DiscardWt_n");
  #ifndef NO_AD_INITIALIZE
  DiscardWt_n.initialize();
  #endif
  DiscardWt_rms.allocate("DiscardWt_rms");
  #ifndef NO_AD_INITIALIZE
  DiscardWt_rms.initialize();
  #endif
  XCatchWt_SE.allocate(FirstYear,LastYear,"XCatchWt_SE");
  #ifndef NO_AD_INITIALIZE
    XCatchWt_SE.initialize();
  #endif
		XCatchWt_SE.fill_seqadd(10000.0,0.0);
  Bycatch_Pred.allocate(FirstYear,LastYear,1,BLptN,"Bycatch_Pred");
  #ifndef NO_AD_INITIALIZE
    Bycatch_Pred.initialize();
  #endif
  Bycatch_RSS.allocate("Bycatch_RSS");
  #ifndef NO_AD_INITIALIZE
  Bycatch_RSS.initialize();
  #endif
  Bycatch_n.allocate("Bycatch_n");
  #ifndef NO_AD_INITIALIZE
  Bycatch_n.initialize();
  #endif
  Bycatch_rms.allocate("Bycatch_rms");
  #ifndef NO_AD_INITIALIZE
  Bycatch_rms.initialize();
  #endif
  BycatchWt_Pred.allocate(FirstYear,LastYear,"BycatchWt_Pred");
  #ifndef NO_AD_INITIALIZE
    BycatchWt_Pred.initialize();
  #endif
  BycatchWt_RSS.allocate("BycatchWt_RSS");
  #ifndef NO_AD_INITIALIZE
  BycatchWt_RSS.initialize();
  #endif
  BycatchWt_n.allocate("BycatchWt_n");
  #ifndef NO_AD_INITIALIZE
  BycatchWt_n.initialize();
  #endif
  BycatchWt_rms.allocate("BycatchWt_rms");
  #ifndef NO_AD_INITIALIZE
  BycatchWt_rms.initialize();
  #endif
  SportCatchWt_Pred.allocate(FirstYear,LastYear,"SportCatchWt_Pred");
  #ifndef NO_AD_INITIALIZE
    SportCatchWt_Pred.initialize();
  #endif
  SportCatch_Pred_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SportCatch_Pred_F");
  #ifndef NO_AD_INITIALIZE
    SportCatch_Pred_F.initialize();
  #endif
  SportCatch_Pred_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SportCatch_Pred_M");
  #ifndef NO_AD_INITIALIZE
    SportCatch_Pred_M.initialize();
  #endif
  SportCatch_Pred_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"SportCatch_Pred_T");
  #ifndef NO_AD_INITIALIZE
    SportCatch_Pred_T.initialize();
  #endif
  SportCatchWt_RSS.allocate("SportCatchWt_RSS");
  #ifndef NO_AD_INITIALIZE
  SportCatchWt_RSS.initialize();
  #endif
  SportCatchWt_n.allocate("SportCatchWt_n");
  #ifndef NO_AD_INITIALIZE
  SportCatchWt_n.initialize();
  #endif
  SportCatchWt_rms.allocate("SportCatchWt_rms");
  #ifndef NO_AD_INITIALIZE
  SportCatchWt_rms.initialize();
  #endif
  PersUseWt_Pred.allocate(FirstYear,LastYear,"PersUseWt_Pred");
  #ifndef NO_AD_INITIALIZE
    PersUseWt_Pred.initialize();
  #endif
  PersUse_Pred_F.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"PersUse_Pred_F");
  #ifndef NO_AD_INITIALIZE
    PersUse_Pred_F.initialize();
  #endif
  PersUse_Pred_M.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"PersUse_Pred_M");
  #ifndef NO_AD_INITIALIZE
    PersUse_Pred_M.initialize();
  #endif
  PersUse_Pred_T.allocate(FirstYear,LastYear,SMinAge,SMaxAge,"PersUse_Pred_T");
  #ifndef NO_AD_INITIALIZE
    PersUse_Pred_T.initialize();
  #endif
  PersUseWt_RSS.allocate("PersUseWt_RSS");
  #ifndef NO_AD_INITIALIZE
  PersUseWt_RSS.initialize();
  #endif
  PersUseWt_n.allocate("PersUseWt_n");
  #ifndef NO_AD_INITIALIZE
  PersUseWt_n.initialize();
  #endif
  PersUseWt_rms.allocate("PersUseWt_rms");
  #ifndef NO_AD_INITIALIZE
  PersUseWt_rms.initialize();
  #endif
  CatchN_Pred.allocate(FirstYear,LastYear,"CatchN_Pred");
  #ifndef NO_AD_INITIALIZE
    CatchN_Pred.initialize();
  #endif
  CatchN_RSS.allocate("CatchN_RSS");
  #ifndef NO_AD_INITIALIZE
  CatchN_RSS.initialize();
  #endif
  CatchN_n.allocate("CatchN_n");
  #ifndef NO_AD_INITIALIZE
  CatchN_n.initialize();
  #endif
  CatchN_rms.allocate("CatchN_rms");
  #ifndef NO_AD_INITIALIZE
  CatchN_rms.initialize();
  #endif
  XCatchN_SE.allocate(FirstYear,LastYear,"XCatchN_SE");
  #ifndef NO_AD_INITIALIZE
    XCatchN_SE.initialize();
  #endif
		XCatchN_SE.fill_seqadd(1000.0,0.0);
  SteadyCQ_PSS.allocate("SteadyCQ_PSS");
  #ifndef NO_AD_INITIALIZE
  SteadyCQ_PSS.initialize();
  #endif
  SelSmooth_PSS.allocate("SelSmooth_PSS");
  #ifndef NO_AD_INITIALIZE
  SelSmooth_PSS.initialize();
  #endif
  LastF_PSS.allocate("LastF_PSS");
  #ifndef NO_AD_INITIALIZE
  LastF_PSS.initialize();
  #endif
  LastF_SD.allocate("LastF_SD");
  #ifndef NO_AD_INITIALIZE
  LastF_SD.initialize();
  #endif
		LastF_SD = 0.0001;
  UnevenSexRatio_PSS.allocate("UnevenSexRatio_PSS");
  #ifndef NO_AD_INITIALIZE
  UnevenSexRatio_PSS.initialize();
  #endif
  UnevenSexRatio_SD.allocate("UnevenSexRatio_SD");
  #ifndef NO_AD_INITIALIZE
  UnevenSexRatio_SD.initialize();
  #endif
		UnevenSexRatio_SD = 0.01;
  WildYearClass_PSS.allocate("WildYearClass_PSS");
  #ifndef NO_AD_INITIALIZE
  WildYearClass_PSS.initialize();
  #endif
  WildYearClass_SD.allocate("WildYearClass_SD");
  #ifndef NO_AD_INITIALIZE
  WildYearClass_SD.initialize();
  #endif
		WildYearClass_SD = 2.3;  // 2.3 = log(10)
  WildR_PSS.allocate("WildR_PSS");
  #ifndef NO_AD_INITIALIZE
  WildR_PSS.initialize();
  #endif
  WildR_SD.allocate("WildR_SD");
  #ifndef NO_AD_INITIALIZE
  WildR_SD.initialize();
  #endif
		WildR_SD = 2.3; // 2.3 = log(10) 
  SteadySQ_PSS.allocate("SteadySQ_PSS");
  #ifndef NO_AD_INITIALIZE
  SteadySQ_PSS.initialize();
  #endif
  TrendlessSQ_PSS.allocate("TrendlessSQ_PSS");
  #ifndef NO_AD_INITIALIZE
  TrendlessSQ_PSS.initialize();
  #endif
  SQ_bhat_SD.allocate("SQ_bhat_SD");
  #ifndef NO_AD_INITIALIZE
  SQ_bhat_SD.initialize();
  #endif
		if (TrendlessSQFlag == 0) SQ_bhat_SD = 100.0; else SQ_bhat_SD = 0.0001;
  CCatch.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex3,"CCatch");
  #ifndef NO_AD_INITIALIZE
    CCatch.initialize();
  #endif
  CCatch_F.allocate(FirstYear,LastYear,1,LastAge,"CCatch_F");
  #ifndef NO_AD_INITIALIZE
    CCatch_F.initialize();
  #endif
  CCatch_M.allocate(FirstYear,LastYear,1,LastAge,"CCatch_M");
  #ifndef NO_AD_INITIALIZE
    CCatch_M.initialize();
  #endif
  CCatch_T.allocate(FirstYear,LastYear,1,LastAge,"CCatch_T");
  #ifndef NO_AD_INITIALIZE
    CCatch_T.initialize();
  #endif
  DCatch.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex3,"DCatch");
  #ifndef NO_AD_INITIALIZE
    DCatch.initialize();
  #endif
  DCatch_F.allocate(FirstYear,LastYear,1,LastAge,"DCatch_F");
  #ifndef NO_AD_INITIALIZE
    DCatch_F.initialize();
  #endif
  DCatch_M.allocate(FirstYear,LastYear,1,LastAge,"DCatch_M");
  #ifndef NO_AD_INITIALIZE
    DCatch_M.initialize();
  #endif
  DCatch_T.allocate(FirstYear,LastYear,1,LastAge,"DCatch_T");
  #ifndef NO_AD_INITIALIZE
    DCatch_T.initialize();
  #endif
  BCatch.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex3,"BCatch");
  #ifndef NO_AD_INITIALIZE
    BCatch.initialize();
  #endif
  BCatch_F.allocate(FirstYear,LastYear,1,LastAge,"BCatch_F");
  #ifndef NO_AD_INITIALIZE
    BCatch_F.initialize();
  #endif
  BCatch_M.allocate(FirstYear,LastYear,1,LastAge,"BCatch_M");
  #ifndef NO_AD_INITIALIZE
    BCatch_M.initialize();
  #endif
  BCatch_T.allocate(FirstYear,LastYear,1,LastAge,"BCatch_T");
  #ifndef NO_AD_INITIALIZE
    BCatch_T.initialize();
  #endif
  RCatch.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex3,"RCatch");
  #ifndef NO_AD_INITIALIZE
    RCatch.initialize();
  #endif
  RCatch_F.allocate(FirstYear,LastYear,1,LastAge,"RCatch_F");
  #ifndef NO_AD_INITIALIZE
    RCatch_F.initialize();
  #endif
  RCatch_M.allocate(FirstYear,LastYear,1,LastAge,"RCatch_M");
  #ifndef NO_AD_INITIALIZE
    RCatch_M.initialize();
  #endif
  RCatch_T.allocate(FirstYear,LastYear,1,LastAge,"RCatch_T");
  #ifndef NO_AD_INITIALIZE
    RCatch_T.initialize();
  #endif
  PCatch.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex3,"PCatch");
  #ifndef NO_AD_INITIALIZE
    PCatch.initialize();
  #endif
  PCatch_F.allocate(FirstYear,LastYear,1,LastAge,"PCatch_F");
  #ifndef NO_AD_INITIALIZE
    PCatch_F.initialize();
  #endif
  PCatch_M.allocate(FirstYear,LastYear,1,LastAge,"PCatch_M");
  #ifndef NO_AD_INITIALIZE
    PCatch_M.initialize();
  #endif
  PCatch_T.allocate(FirstYear,LastYear,1,LastAge,"PCatch_T");
  #ifndef NO_AD_INITIALIZE
    PCatch_T.initialize();
  #endif
  MCatch.allocate(FirstYear,LastYear,1,LastAge,Sex1,Sex3,"MCatch");
  #ifndef NO_AD_INITIALIZE
    MCatch.initialize();
  #endif
  MCatch_F.allocate(FirstYear,LastYear,1,LastAge,"MCatch_F");
  #ifndef NO_AD_INITIALIZE
    MCatch_F.initialize();
  #endif
  MCatch_M.allocate(FirstYear,LastYear,1,LastAge,"MCatch_M");
  #ifndef NO_AD_INITIALIZE
    MCatch_M.initialize();
  #endif
  MCatch_T.allocate(FirstYear,LastYear,1,LastAge,"MCatch_T");
  #ifndef NO_AD_INITIALIZE
    MCatch_T.initialize();
  #endif
  CCPUE_True_F.allocate(FirstYear,LastYear,1,LastAge,"CCPUE_True_F");
  #ifndef NO_AD_INITIALIZE
    CCPUE_True_F.initialize();
  #endif
  CCPUE_True_M.allocate(FirstYear,LastYear,1,LastAge,"CCPUE_True_M");
  #ifndef NO_AD_INITIALIZE
    CCPUE_True_M.initialize();
  #endif
  CCPUE_True_T.allocate(FirstYear,LastYear,1,LastAge,"CCPUE_True_T");
  #ifndef NO_AD_INITIALIZE
    CCPUE_True_T.initialize();
  #endif
  SurvProp_True_F.allocate(FirstYear,LastYear,1,LastAge,"SurvProp_True_F");
  #ifndef NO_AD_INITIALIZE
    SurvProp_True_F.initialize();
  #endif
  SurvProp_True_M.allocate(FirstYear,LastYear,1,LastAge,"SurvProp_True_M");
  #ifndef NO_AD_INITIALIZE
    SurvProp_True_M.initialize();
  #endif
  SurvProp_True_T.allocate(FirstYear,LastYear,1,LastAge,"SurvProp_True_T");
  #ifndef NO_AD_INITIALIZE
    SurvProp_True_T.initialize();
  #endif
  SurvCPUE_True_F.allocate(FirstYear,LastYear,1,LastAge,"SurvCPUE_True_F");
  #ifndef NO_AD_INITIALIZE
    SurvCPUE_True_F.initialize();
  #endif
  SurvCPUE_True_M.allocate(FirstYear,LastYear,1,LastAge,"SurvCPUE_True_M");
  #ifndef NO_AD_INITIALIZE
    SurvCPUE_True_M.initialize();
  #endif
  SurvCPUE_True_T.allocate(FirstYear,LastYear,1,LastAge,"SurvCPUE_True_T");
  #ifndef NO_AD_INITIALIZE
    SurvCPUE_True_T.initialize();
  #endif
  R6.allocate(FirstYear,LastYear+1,"R6");
  #ifndef NO_AD_INITIALIZE
    R6.initialize();
  #endif
  R8.allocate(FirstYear,LastYear+1,"R8");
  #ifndef NO_AD_INITIALIZE
    R8.initialize();
  #endif
  N8Plus_F.allocate(FirstYear,LastYear+1,"N8Plus_F");
  #ifndef NO_AD_INITIALIZE
    N8Plus_F.initialize();
  #endif
  N8Plus_M.allocate(FirstYear,LastYear+1,"N8Plus_M");
  #ifndef NO_AD_INITIALIZE
    N8Plus_M.initialize();
  #endif
  TBio8Plus_F.allocate(FirstYear,LastYear+1,"TBio8Plus_F");
  #ifndef NO_AD_INITIALIZE
    TBio8Plus_F.initialize();
  #endif
  TBio8Plus_M.allocate(FirstYear,LastYear+1,"TBio8Plus_M");
  #ifndef NO_AD_INITIALIZE
    TBio8Plus_M.initialize();
  #endif
  LBio.allocate(FirstYear,LastYear+1,"LBio");
  #ifndef NO_AD_INITIALIZE
    LBio.initialize();
  #endif
  SBio.allocate(FirstYear,LastYear+1,"SBio");
  #ifndef NO_AD_INITIALIZE
    SBio.initialize();
  #endif
  EBio.allocate(FirstYear,LastYear+1,"EBio");
  #ifndef NO_AD_INITIALIZE
    EBio.initialize();
  #endif
  EBioFixed.allocate(FirstYear,LastYear+1,"EBioFixed");
  #ifndef NO_AD_INITIALIZE
    EBioFixed.initialize();
  #endif
  LastEBioFixed.allocate("LastEBioFixed");
  LastEBioFixedToo.allocate("LastEBioFixedToo");
  LastSBio.allocate("LastSBio");
  EBioSurv.allocate(FirstYear,LastYear+1,"EBioSurv");
  #ifndef NO_AD_INITIALIZE
    EBioSurv.initialize();
  #endif
  R8SD.allocate(FirstYear,LastYear+1,"R8SD");
}

void model_parameters::userfunction(void)
{
  //
  // cout << "Hi, Mommy!" << endl;
  //
  // Initialize objective function components.
  //
  SSTotal = 0.0;
  RSSTotal = 0.0;
  RSSNobs = 0.0;
  PSSTotal = 0.0;
  //
  // Fill the working arrays of age- and sex-specfic values
  // M, CF, CQ, CSel, SQ, SSel, BF, BSel etc. according to their
  // various parameterizations.
  //
     Fill_M(); 
  //
     Fill_CF();
  //
     if (FitLastFFlag != 0) Compute_LastF_PSS();
  //
     Fill_CQ();
  //
     Compute_SteadyCQ_PSS();
  //
     Fill_CSelL();
  //
     Fill_DF();
  //
     Fill_SQ();
  //
     if (SteadySQFlag != 0) Compute_SteadySQ_PSS();
  //
     Fill_SSelL();
  //
     Fill_RF_and_PF();
  //
     Fill_BSelL();
  //
     if (SelSmoothFlag==1) Compute_SelSmooth_PSS();
  //
     Compute_selectivity_at_age();
  //
     Compute_mortality_rates_at_age();
  //
     Fill_InitN();
  //
     Fill_R();
  //
     Initialize_N();
  //
     Compute_removals_and_survivors();
  //
  // Maybe switch on the internal robustification flag.
     if (RobustifyFlag != 0 && current_phase() == 2) Robust = 1;
        else Robust = 0;
  //
     Compute_Catch_RSS();
  //
     Compute_CCPUE_RSS();
  //
     Compute_SurvProp_RSS();
  //
     Compute_SurvCPUE_RSS();
  //
     Compute_CPUE_Totals_RSS();
  //
     Compute_DiscardWt_RSS();
  //
     Compute_Bycatch_RSS();
     Compute_BycatchWt_RSS();
  //
     Compute_SportCatchWt_RSS();
  //
     Compute_PersUseWt_RSS();
  //
     Compute_CatchN_RSS();
  //
     SSTotal = RSSTotal + PSSTotal;
     SSTotal += sq(ProForma); // Initialized to zero and kept there.
     MinusLogL = SSTotal/8.0;
  //
     if (sd_phase()) Compute_outputs();
  //
  // cout << "Bye, Mommy!" << endl;
  //
}

void model_parameters::Fill_M(void)
{
  //
  // Fill in the natural mortality matrix.
  //
  for (y=FirstYear; y<=LastYear; y++)
     {
     M(y,1) = MPar;
     if (EstMMFlag != 0) M(y,2) = MPar_M; else M(y,2) = MPar;
     }
}

void model_parameters::Fill_CF(void)
{
  //
  // Fill in the commercial fishing mortality matrix
  //
  for (y=FirstYear; y<=LastYear; y++)
     {
     CF(y,1) = CFPar(y); // Females.
     CF(y,2) = CQMX * CFPar(y); // Males.
     }
   //
}

void model_parameters::Compute_LastF_PSS(void)
{
  //
  // Assess a heavy penalty on deviations from the specified LastF.
  //
  LastF_PSS = sq( (CFPar(LastYear) - LastF)/LastF_SD );
  PSSTotal += LastF_PSS;
  //
}

void model_parameters::Fill_CQ(void)
{
  //
  // Fill in working matrix CQ from waypoint and path type params.
  // GOOD_COP has made sure that CQ is estimated in FirstYear.
  //
  // Scale the parameter.
  //
  for (w=1; w<=CQEstN; w++) CQEst(w) = CQEstPar(w) * 1.0E-6;
  //
  for (w=1; w<=CQEstN; w++)
     {
     // Starting value on this segment is CQEst(w).
     StartYear = CQEstYears(w);
     StartVal = CQEst(w);
     // Figure out StopYear and StopVal.
     if (w == CQEstN)
        {
        // Last (or only) waypoint. Use this value for remainder
        // of series regardless of value of CQEstPathTypes(w).
        StopYear = LastYear;
        StopVal = StartVal;
        } else
        {
        // First or intermediate waypoint. Determine StopYear, StopVal.
        StopYear = CQEstYears(w+1);
        if (CQEstPathTypes(w) == 0) 
           StopVal = StartVal; else StopVal = CQEst(w+1);
        }
     // Compute PathLength and StepVal.
     PathLength = StopYear - StartYear;
     StepVal = (StopVal - StartVal);
     if (PathLength > 0) StepVal = StepVal/PathLength;
     // Assign values point by point.
     for (istep=0; istep<=PathLength; istep++)
        {
        y = StartYear + istep;
        CQ(y,1) = StartVal + istep * StepVal; // Females.
        CQ(y,2) = CQMX * (StartVal + istep * StepVal); // Males.
        }
     // Done with this segment.
     } // End loop on segment index w.
  //
}

void model_parameters::Compute_SteadyCQ_PSS(void)
{
  //
  // Compute SteadyCQ_PSS
  //
  dvariable DeltaCQ;
  SteadyCQ_PSS = 0.0;
  for (s=1; s<=2; s++)
     for (y=FirstYear+1; y<=CLastYearFit; y++)
        {
        DeltaCQ = (CQ(y,s) - CQ(y-1,s)) / CQ(y-1,s); 
        if (y==1984 && DeltaCQ > HookCorrMax-1)
           SteadyCQ_PSS += sq( (DeltaCQ - (HookCorrMax-1)) / 0.01 );
        if (y!=1984)
           SteadyCQ_PSS += sq(DeltaCQ/SteadyCQ_SD);
        }
  PSSTotal += SteadyCQ_PSS;
  //
}

void model_parameters::Fill_CSelL(void)
{
  //
  // Fill in working array CSelL from path & waypoint params.
  // GOOD_COP has assured that an estimate is made in FirstYear.
  //
  // Compute implied estimates CSelLEst at waypoints.
  // Interpretation of params depends on CSelLForm.
  //
  // First load split-sex parameter array CSelLParSplit.
  //  If (SplitMalesFlag) load CSelLPar_M into male tier else CSelLPar.
  for (w=1; w<=CSelLEstN; w++)
     for (p=1; p<=CSelLParN; p++)
        {
        CSelLParSplit(w,p,1) = CSelLPar(w,p); // Females
        if (SplitMalesFlag == 0) CSelLParSplit(w,p,2) = CSelLPar(w,p);
                            else CSelLParSplit(w,p,2) = CSelLPar_M(w,p);
        } // End loops on w, p.
  //
  // Build split-sex selectivity array CSelLEst.
  //
  for (s=1; s<=2; s++)
  {
  if (CSelLForm==1)
  // Free except zero at SLptList(1) and one at SLptOne. 
  // Scale by 5 because params are all (0,1).
  for (w=1; w<=CSelLEstN; w++)
     {
     CSelLEst(w,1,s) = 0.0;
     CSelLEst(w,vOne,s) = 1.0;
     for (v=2; v<vOne; v++) CSelLEst(w,v,s) = 5.0 * CSelLParSplit(w,v-1,s);
     for (v=vOne+1; v<=SLptN; v++) CSelLEst(w,v,s) = 5.0 * CSelLParSplit(w,v-2,s);
     } // End loop on waypoint w.
  else if (CSelLForm==2)
  // Domed on either side of SLptOne
  for (w=1; w<=CSelLEstN; w++)
      {
      CSelLEst(w,vOne,s) = 1.0;
      for (v=vOne-1; v>=1; v--) CSelLEst(w,v,s) = CSelLEst(w,v+1,s) * CSelLParSplit(w,v,s);
      for (v=vOne+1; v<=SLptN; v++) CSelLEst(w,v,s) = CSelLEst(w,v-1,s) * CSelLParSplit(w,v-1,s);
      } // End loop on waypoint w.
  else if (CSelLForm==3)
  // Asymptotic.
  for (w=1; w<=CSelLEstN; w++)
      {
      CSelLEst(w,vOne,s) = 1.0;
      for (v=vOne-1; v>=1; v--) CSelLEst(w,v,s) = CSelLEst(w,v+1,s) * CSelLParSplit(w,v,s);
      for (v=vOne+1; v<=SLptN; v++) CSelLEst(w,v,s) = 1.0;
      } // End loop on waypoint w.
  //
  // Assign waypoints and compute paths.
  //
  for (w=1; w<=CSelLEstN; w++)
     {
     // Starting value on this segment is CSelLEst(w).
     StartYear = CSelLEstYears(w);
     for (v=1; v<=SLptN; v++)
        StartVec(v) = CSelLEst(w,v,s);
     // Figure out StopYear and StopVec.
     if (w == CSelLEstN)
        {
        // Last (or only) waypoint. Use this value for remainder
        // of series regardless of value of CSelLEstPathTypes(w).
        StopYear = LastYear;
        StopVec = StartVec;
        } else
        {
        // First or intermediate waypoint. Determine StopYear, StopVec.
        StopYear = CSelLEstYears(w+1);
        if (CSelLEstPathTypes(w) == 0) 
           StopVec = StartVec;
           else for(v=1; v<=SLptN; v++) StopVec(v) = CSelLEst(w+1,v,s);
        }
     // Compute PathLength and StepVec.
     PathLength = StopYear - StartYear;
     StepVec = (StopVec - StartVec);
     if (PathLength > 0) StepVec = StepVec/PathLength;
     // Assign values point by point.
     for (istep=0; istep<=PathLength; istep++)
     for (v=1; v<=SLptN; v++)
        CSelL(StartYear+istep,v,s) = StartVec(v) + istep * StepVec(v);
     // Done with this segment.
     } // End loop on waypoint.
  } // End loop on sex.
  //
}

void model_parameters::Fill_DF(void)
{
  //
  // Fill in the sublegal discard mortality matrix
  //
  for (y=FirstYear; y<=LastYear; y++)
     DF(y) = DFPar(y);
   //
}

void model_parameters::Fill_SQ(void)
{
  //
  // Fill in working matrix SQ from waypoint and path type params.
  // GOOD_COP has made sure that SQ is estimated in FirstYear.
  //
  // Scale the parameter.
  //
  for(w=1; w<=SQEstN; w++) SQEst(w) = SQEstPar(w) * 1.0E-6;
  //
  for (w=1; w<=SQEstN; w++)
     {
     // Starting value on this segment is SQEst(w).
     StartYear = SQEstYears(w);
     StartVal = SQEst(w);
     // Figure out StopYear and StopVal.
     if (w == SQEstN)
        {
        // Last (or only) waypoint. Use this value for remainder
        // of series regardless of value of SQEstPathTypes(w).
        StopYear = LastYear;
        StopVal = StartVal;
        } else
        {
        // First or intermediate waypoint. Determine StopYear, StopVal.
        StopYear = SQEstYears(w+1);
        if (SQEstPathTypes(w) == 0) 
           StopVal = StartVal; else StopVal = SQEst(w+1);
        }
     // Compute PathLength and StepVal.
     PathLength = StopYear - StartYear;
     StepVal = (StopVal - StartVal);
     if (PathLength > 0) StepVal = StepVal/PathLength;
     // Assign values point by point.
     for (istep=0; istep<=PathLength; istep++)
        {
        y = StartYear + istep;
        SQ(y,1) = StartVal + istep * StepVal; // Females.
        SQ(y,2) = SQMX * (StartVal + istep * StepVal); // Males.
        } // End loop on istep.
     // Done with this segment.
     } // End loop on w.
  //
}

void model_parameters::Compute_SteadySQ_PSS(void)
{
  //
  // Compute penalty on variance in log(SQEst) -- post 1984 only.
  // Also compute penalty on any trend (departure from zero slope).
  //
  //sig_PSS = 0.0;
  SteadySQ_PSS = 0.0;
  dvariable SQSum;
  dvariable SQMean;
  dvariable YearSum;
  dvariable YearMean;
  dvariable xySum;
  dvariable xxSum;
  SQSum = 0.0;
  YearSum = 0.0;
  int nyrs = 0;
  for (y=FirstYear; y<=SLastYearFit; y++)
     {
     if (y < 1984) continue;
     nyrs += 1;
     SQSum += SQ(y,1);
     YearSum += y;
     }
  if (nyrs > 1)
     {
     SQMean = SQSum/nyrs;
     YearMean = YearSum/nyrs;
     xxSum = 0.0;
     xySum = 0.0;
     for (y=FirstYear; y<=SLastYearFit; y++)
        {
        if (y < 1984) continue;
        SteadySQ_PSS += sq( (log(SQ(y,1)) - log(SQMean) ) / SteadySQ_SD );
        xxSum += sq(y - YearMean);
        xySum += (y - YearMean) * (log(SQ(y,1)) - log(SQMean));
        } // End loop on y.
     } // End condition on nyrs.
  SQ_bhat = xySum / xxSum;
  TrendlessSQ_PSS = sq(SQ_bhat/SQ_bhat_SD);
  if (TrendlessSQFlag != 0) PSSTotal += TrendlessSQ_PSS;
  if (SteadySQFlag != 0) PSSTotal += SteadySQ_PSS;
  //
}

void model_parameters::Fill_SSelL(void)
{
  //
  // Fill in working array SSelL from path & waypoint params.
  // GOOD_COP has assured that an estimate is made in FirstYear.
  //
  // Compute implied estimates SSelLEst at waypoints.
  // Interpretation of params depends on SSelLForm.
  //
  // First load split-sex parameter array SSelLParSplit.
  //  If (SplitMalesFlag) load SSelLPar_M into male tier else SSelLPar.
  for (w=1; w<=SSelLEstN; w++)
     for (p=1; p<=SSelLParN; p++)
        {
        SSelLParSplit(w,p,1) = SSelLPar(w,p); // Females
        if (SplitMalesFlag == 0) SSelLParSplit(w,p,2) = SSelLPar(w,p);
                            else SSelLParSplit(w,p,2) = SSelLPar_M(w,p);
        } // End loops on w, p.
  //
  // Build split-sex selectivity array SSelLEst.
  //
  for (s=1; s<=2; s++)
  {
  if (SSelLForm==1)
  // Free except zero at SLptList(1) and one at SLptOne. 
  // Scale by 5 because params are all (0,1).
  for (w=1; w<=SSelLEstN; w++)
     {
     SSelLEst(w,1,s) = 0.0;
     SSelLEst(w,vOne,s) = 1.0;
     for (v=2; v<vOne; v++) SSelLEst(w,v,s) = 5.0 * SSelLParSplit(w,v-1,s);
     for (v=vOne+1; v<=SLptN; v++) SSelLEst(w,v,s) = 5.0 * SSelLParSplit(w,v-2,s);
     } // End loop on waypoint w.
  else if (SSelLForm==2)
  // Domed on either side of SLptOne
  for (w=1; w<=SSelLEstN; w++)
      {
      SSelLEst(w,vOne,s) = 1.0;
      for (v=vOne-1; v>=1; v--) SSelLEst(w,v,s) = SSelLEst(w,v+1,s) * SSelLParSplit(w,v,s);
      for (v=vOne+1; v<=SLptN; v++) SSelLEst(w,v,s) = SSelLEst(w,v-1,s) * SSelLParSplit(w,v-1,s);
      } // End loop on waypoint w.
  else if (SSelLForm==3)
  // Asymptotic.
  for (w=1; w<=SSelLEstN; w++)
      {
      SSelLEst(w,vOne,s) = 1.0;
      for (v=vOne-1; v>=1; v--) SSelLEst(w,v,s) = SSelLEst(w,v+1,s) * SSelLParSplit(w,v,s);
      for (v=vOne+1; v<=SLptN; v++) SSelLEst(w,v,s) = 1.0;
      } // End loop on waypoint w.
  //
  // Assign waypoints and compute paths.
  //
  for (w=1; w<=SSelLEstN; w++)
     {
     // Starting value on this segment is SSelLEst(w).
     StartYear = SSelLEstYears(w);
     for (v=1; v<=SLptN; v++)
        StartVec(v) = SSelLEst(w,v,s);
     // Figure out StopYear and StopVec.
     if (w == SSelLEstN)
        {
        // Last (or only) waypoint. Use this value for remainder
        // of series regardless of value of SSelLEstPathTypes(w).
        StopYear = LastYear;
        StopVec = StartVec;
        } else
        {
        // First or intermediate waypoint. Determine StopYear, StopVec.
        StopYear = SSelLEstYears(w+1);
        if (SSelLEstPathTypes(w) == 0) 
           StopVec = StartVec;
           else for(v=1; v<=SLptN; v++) StopVec(v) = SSelLEst(w+1,v,s);
        }
     // Compute PathLength and StepVec.
     PathLength = StopYear - StartYear;
     StepVec = (StopVec - StartVec);
     if (PathLength > 0) StepVec = StepVec/PathLength;
     // Assign values point by point.
     for (istep=0; istep<=PathLength; istep++)
     for (v=1; v<=SLptN; v++)
        SSelL(StartYear+istep,v,s) = StartVec(v) + istep * StepVec(v);
     // Done with this segment.
     } // End loop on waypoint.
  } // End loop on sex.
  //
}

void model_parameters::Fill_RF_and_PF(void)
{
  //
  // Fill in the recreational and psonal use fishing mortality matrices.
  //
  for (y=FirstYear; y<=LastYear; y++)
     {
     RF(y,1) = RFPar(y); // Females.
     RF(y,2) = SQMX * RFPar(y); // Males.
     PF(y,1) = PFPar(y); // Females.
     PF(y,2) = SQMX * PFPar(y); // Males.
     }
   //
}

void model_parameters::Fill_BSelL(void)
{
  //
  // Fill in working array BSelL from path and waypoint params.
  // GOOD_COP has assured that an estimate is made in FirstYear.
  //
  // Compute implied estimates BSelLEst at waypoints.
  // For bycatch selectivity, each row of the param matrix BSelLPar
  // is a set of multipliers to be applied on either side of BLptOne,
  // so a row has BSelLParN = BLptN-1 elements.
  // The limits placed on BSelLPar determine whether any of the
  // bycatch selectivities can exceed 1.0.
  //
  for (w=1; w<=BSelLEstN; w++)
     {
     BSelLEst(w,vOneB) = 1.0;
     for (v=vOneB-1; v>=1; v--) BSelLEst(w,v) = BSelLEst(w,v+1) * BSelLPar(w,v);
     for (v=vOneB+1; v<=BLptN; v++) BSelLEst(w,v) = BSelLEst(w,v-1) * BSelLPar(w,v-1);
     }
  //
  // Assign waypoints and compute paths.
  //
  for (w=1; w<=BSelLEstN; w++)
     {
     // Starting value on this segment is BSelLEst(w).
     StartYear = BSelLEstYears(w);
     StartVecB = BSelLEst(w);
     // Figure out StopYear and StopVecB.
     if (w == BSelLEstN)
        {
        // Last (or only) waypoint. Use this value for remainder
        // of series regardless of value of BSelLEstPathTypes(w).
        StopYear = LastYear;
        StopVecB = StartVecB;
        } else
        {
        // First or intermediate waypoint. Determine StopYear, StopVecB.
        StopYear = BSelLEstYears(w+1);
        if (BSelLEstPathTypes(w) == 0) 
           StopVecB = StartVecB; else StopVecB = BSelLEst(w+1);
        }
     // Compute PathLength and StepVecB.
     PathLength = StopYear - StartYear;
     StepVecB = (StopVecB - StartVecB);
     if (PathLength > 0) StepVecB = StepVecB/PathLength;
     // Assign values point by point.
     for (istep=0; istep<=PathLength; istep++)
     for (v=1; v<=BLptN; v++)
     for (s=1; s<=2; s++)
        BSelL(StartYear+istep,v,s) = StartVecB(v) + istep * StepVecB(v);
     // Done with this segment.
     }
  //
}

void model_parameters::Compute_selectivity_at_age(void)
{
  //
  // Compute all the age-specific selectivities from length-specific
  // schedules and mean (true) length in either the survey or the bycatch.
  //
  for (y=FirstYear; y<=LastYear; y++)
     {
     // Construct year-specific matrices CSelLy and SSelLy.
     // Each row is a sex-specific vector that can be used with approx().
     for (s=1; s<=2; s++)
     for (v=1; v<= SLptN; v++)
        {
        CSelLy(s,v) = CSelL(y,v,s);
        SSelLy(s,v) = SSelL(y,v,s);
        }
     // Same for BSelLy.
     for (s=1; s<=2; s++)
     for (v=1; v<=BLptN; v++)
        BSelLy(s,v) = BSelL(y,v,s);
     //
     // Run through ages and sexes doing the interpolation.
     for (b=1; b<=LastAge; b++)
     for (s=1; s<=2; s++)
        {
        // First hook-and-line fisheries.
        if (b < SMinAge)
           {
           CSel(y,b,s) = 0.0;
           DSel(y,b,s) = 0.0;
           FSel(y,b,s) = 0.0;
           SSel(y,b,s) = 0.0;
           } else
           {
           if (SexFlag==1)
              { // Use sex-specific mean length at age.
              CSel(y,b,s) = approx(SLptList, CSelLy(s), SurvLTrue(y,b,s), 0);
              DSel(y,b,s) = approx(SLptList,     DSelL, SurvLTrue(y,b,s), 0);
              FSel(y,b,s) = approx(SLptList,     FSelL, SurvLTrue(y,b,s), 0);
              SSel(y,b,s) = approx(SLptList, SSelLy(s), SurvLTrue(y,b,s), 0);
              if(survlenFLG>0){SSel(y,b,s) = approx(SLptList, SSelLy(s), popl(y,b,s), 0);}
              } else
              { // Use overall mean length at age for both sexes.
              CSel(y,b,s) = approx(SLptList, CSelLy(s), SurvLTrue(y,b,3), 0);
              DSel(y,b,s) = approx(SLptList,     DSelL, SurvLTrue(y,b,3), 0);
              FSel(y,b,s) = approx(SLptList,     FSelL, SurvLTrue(y,b,3), 0);
              SSel(y,b,s) = approx(SLptList, SSelLy(s), SurvLTrue(y,b,3), 0);
              if(survlenFLG>0){SSel(y,b,s) = approx(SLptList, SSelLy(s), popl(y,b,3), 0);}
              }
           }
        RSel(y,b,s) = SSel(y,b,s);
        PSel(y,b,s) = SSel(y,b,s);
        // Bycatch.
        if (SexFlag==1)
           BSel(y,b,s) = approx(BLptList, BSelLy(s), BycatchLTrue(y,b,s), 0);
           else BSel(y,b,s) = approx(BLptList, BSelLy(s), BycatchLTrue(y,b,3), 0);
        } // End age/sex loop.
     } // End year loop.
  //
}

void model_parameters::Compute_mortality_rates_at_age(void)
{
  //
  // Compute all the year/age/sex-specific mortalities.
  //
  for (y=FirstYear; y<=LastYear; y++)
  for (b=1; b<=LastAge; b++)
  for (s=1; s<=2; s++)
     {
     Cf(y,b,s) = CSel(y,b,s) * CF(y,s);
     Df(y,b,s) = DSel(y,b,s) * DF(y);
     Bf(y,b,s) = BSel(y,b,s) * BF(y);
     Rf(y,b,s) = RSel(y,b,s) * RF(y,s);
     Pf(y,b,s) = PSel(y,b,s) * PF(y,s);
      Z(y,b,s) = Cf(y,b,s) + Df(y,b,s) + Bf(y,b,s) + Rf(y,b,s) + Pf(y,b,s) + M(y,s);
     }
}

void model_parameters::Fill_InitN(void)
{
  //
  // Fill in the first row of the population arrays InitN. To avoid some 
  // poorly determined estimates of initial abundance of the oldest (true) 
  // age groups, they are not estimated but instead computed from the 
  // initial abundance at true age AgePlusFirst (which is really an 
  // observed age), like 20. As a result the total abundance estimate for
  // the fish that were (true age) 20+ in 1974 should be OK, but their 
  // distn among ages will be assigned.
  //
  // Scale the parameter.
  //
  for (b=2; b<=AgePlusFirst; b++)
     for(s=1; s<=2; s++)
        InitNSeen(b,s) = InitNSeenPar(b,s) * 1.0E6;
  //
  // Seen well enough.
  for (b=2; b<=AgePlusFirst; b++)
     {
     for (s=1; s<=2; s++) InitN(b,s) = InitNSeen(b,s);
     InitN(b,3) = InitN(b,1) + InitN(b,2);
     }
  // Not seen well enough.
  // Get Z by sex in FirstYear.
  for (s=1; s<=2; s++)
     OldZ(s) = CF(FirstYear,s) + M(FirstYear,s);
  //
  for (b=AgePlusFirst+1; b<=LastAge; b++)
     {
     for (s=1; s<=2; s++)
        InitN(b,s) = InitN(AgePlusFirst,s) * 
                     exp(-(b - AgePlusFirst) * OldZ(s));
     InitN(b,3) = InitN(b,1) + InitN(b,2);
     }
  // Jack up the plus group.
  for (s=1; s<=2; s++) InitN(LastAge,s) /= (1.0 - exp(-OldZ(s)));
  InitN(LastAge,3) = InitN(LastAge,1) + InitN(LastAge,2);
  //
  // Compute UnevenSexRatio_PSS.
  dvariable pf; // Prop. female at age.
  dvariable pflast = 0.5;
  UnevenSexRatio_PSS = 0.0;
  // Penalize deviations from 0.5 through age 8.
  // Penalize first differences thereafter.
  for (b=2; b<=AgePlusFirst; b++)
     {
     pf = InitN(b,1)/(InitN(b,1) + InitN(b,2));
     if (b <= 8)
        UnevenSexRatio_PSS += sq( (pf - 0.5)/UnevenSexRatio_SD );
        else
        UnevenSexRatio_PSS += sq( (pf - pflast)/UnevenSexRatio_SD );
     pflast = pf;
     }
  PSSTotal += UnevenSexRatio_PSS;
  //
  // Compute WildYearClass_PSS.
  dvariable nt;
  dvariable ntlast = InitN(2,3);
  WildYearClass_PSS = 0.0;
  for (b=3; b<=AgePlusFirst; b++)
     {
     nt = InitN(b,3);
     WildYearClass_PSS += sq( log(nt/ntlast)/WildYearClass_SD );
     }
  PSSTotal += WildYearClass_PSS;
  //
}

void model_parameters::Fill_R(void)
{
  //
  // Fill in the recruitment matrix R.
  // Set unseen recruitments to mean of seen ones.
  //
  // Scale the parameter.
  //
  for(y=FirstYear; y<=LastYearClass+1; y++) RSeen(y) = RSeenPar(y) * 1.0E6;
  //
  // Seen.
  WildR_PSS = 0.0;
  for (y=FirstYear; y<=LastYearClass+1; y++)
     {
     R(y,1) = PropFem * RSeen(y);
     R(y,2) = (1.0 - PropFem) * RSeen(y);
     R(y,3) = RSeen(y);
     if (y > FirstYear) WildR_PSS += sq( log(RSeen(y)/RSeen(y-1)) / WildR_SD );
     }
  PSSTotal += WildR_PSS;
  // Unseen.
  RMean = 0.5 * mean(RSeen);
  for (y=LastYearClass+2; y<=LastYear+1; y++)
     {
     for (s=1; s<=2; s++) R(y,s) = RMean;
     R(y,3) = 2.0 * RMean;
     }
  //
}

void model_parameters::Initialize_N(void)
{
  //
  // Drop InitN and R into N.
  //
  for (b=2; b<=LastAge; b++)
     for (s=1; s<=3; s++)
        N(FirstYear,b,s) = InitN(b,s);
  //
  for (y=FirstYear; y<=LastYear+1; y++)
     for (s=1; s<=3; s++)
        N(y,1,s) = R(y,s);
  //
}

void model_parameters::Compute_removals_and_survivors(void)
{
  //
  // Run the numbers: compute removals and survivors for all
  // sources of mortality, years, ages, and sexes.
  //
  // These are the core calculations of the model.
  //
  for (y=FirstYear; y<=LastYear; y++)
  for (b=1; b<=LastAge; b++)
  for (s=1; s<=2; s++)
     {
     // Average number present during the year.
     NBar(y,b,s) = N(y,b,s) * (1 - exp(-Z(y,b,s))) / Z(y,b,s);
     //
     // All removals.
     CCatch(y,b,s) = Cf(y,b,s) * NBar(y,b,s);
     DCatch(y,b,s) = Df(y,b,s) * NBar(y,b,s);
     BCatch(y,b,s) = Bf(y,b,s) * NBar(y,b,s);
     RCatch(y,b,s) = Rf(y,b,s) * NBar(y,b,s);
     PCatch(y,b,s) = Pf(y,b,s) * NBar(y,b,s);
     MCatch(y,b,s) =  M(y,s)   * NBar(y,b,s);
     //
     // Survivors. Plus group survivors are added to survivors
     // from the next younger age.
     if (b < LastAge)
        N(y+1,b+1,s) = N(y,b,s) * exp(-Z(y,b,s)); else
        N(y+1,b,s) = N(y+1,b,s) + N(y,b,s) * exp(-Z(y,b,s));
     }
  //
  // Done with core calculations.
  //
  // Unload numbers and removals into sex-specific arrays.
  for (y=FirstYear; y<=LastYear+1; y++)
  for (b=1; b<=LastAge; b++)
     {
     N_F(y,b) = N(y,b,1);
     N_M(y,b) = N(y,b,2);
     N_T(y,b) = N_F(y,b) + N_M(y,b);
     }
     //
  for (y=FirstYear; y<=LastYear; y++)
  for (b=1; b<=LastAge; b++)
     {
     NBar_F(y,b) = NBar(y,b,1);
     NBar_M(y,b) = NBar(y,b,2);
     NBar_T(y,b) = NBar_F(y,b) + NBar_M(y,b);
     //
     CCatch_F(y,b) = CCatch(y,b,1);
     CCatch_M(y,b) = CCatch(y,b,2);
     CCatch_T(y,b) = CCatch_F(y,b) + CCatch_M(y,b);
     //
     BCatch_F(y,b) = BCatch(y,b,1);
     BCatch_M(y,b) = BCatch(y,b,2);
     BCatch_T(y,b) = BCatch_F(y,b) + BCatch_M(y,b);
     //
     RCatch_F(y,b) = RCatch(y,b,1);
     RCatch_M(y,b) = RCatch(y,b,2);
     RCatch_T(y,b) = RCatch_F(y,b) + RCatch_M(y,b);
     //
     PCatch_F(y,b) = PCatch(y,b,1);
     PCatch_M(y,b) = PCatch(y,b,2);
     PCatch_T(y,b) = PCatch_F(y,b) + RCatch_M(y,b);
     //
     MCatch_F(y,b) = MCatch(y,b,1);
     MCatch_M(y,b) = MCatch(y,b,2);
     MCatch_T(y,b) = MCatch_F(y,b) + RCatch_M(y,b);
     }
  //
  // Compute model CCPUE, SurvCPUE, and SurvProp at true age,
  // called CCPUE_True, SurvCPUE_True, and SurvProp_True.
  //
  dvariable SurvCPUETot_True;
  for (y=FirstYear; y<=LastYear; y++)
     {
     SurvCPUETot_True = 0.0;
     for (b=1; b<=LastAge; b++)
        {
        CCPUE_True_F(y,b) = CQ(y,1) * CSel(y,b,1) * NBar(y,b,1);
        CCPUE_True_M(y,b) = CQ(y,2) * CSel(y,b,2) * NBar(y,b,2);
        CCPUE_True_T(y,b) = CCPUE_True_F(y,b) + CCPUE_True_M(y,b);
        //
        SurvCPUE_True_F(y,b) = SQ(y,1) * SSel(y,b,1) * NBar(y,b,1);
        SurvCPUE_True_M(y,b) = SQ(y,2) * SSel(y,b,2) * NBar(y,b,2);
        SurvCPUE_True_T(y,b) = SurvCPUE_True_F(y,b) + SurvCPUE_True_M(y,b);
        //
        // Compute predicted total survey CPUE in number on first pass.
        SurvCPUETot_True += SurvCPUE_True_T(y,b);
        } // End first loop on age.
     // Compute SurvProp_True on second pass.
     for (b=1; b<=LastAge; b++)
        {
        SurvProp_True_F(y,b) = SurvCPUE_True_F(y,b)/SurvCPUETot_True;
        SurvProp_True_M(y,b) = SurvCPUE_True_M(y,b)/SurvCPUETot_True;
        SurvProp_True_T(y,b) = SurvCPUE_True_T(y,b)/SurvCPUETot_True;
        } // End second loop on age.
     } // End loop on year.
  //
  //
}

void model_parameters::Compute_SelSmooth_PSS(void)
{
  //
  // Smooth the length-specific selectivities.
  // (Survey and commercial; NOT bycatch.)
  //
  SelSmooth_PSS = 0.0;
  //
  for (s=1; s<=2; s++)
  {
  //
  // Commercial.
  for (w=1; w<=CSelLEstN; w++)
     {
     for (v=1; v<=SLptN; v++) SelVec(v) = CSelLEst(w,v,s);
     SelSmooth_PSS += pen2diffs(SelVec, SelSmooth_SD);
     } // End loop on waypoint.
  // Survey.
  for (w=1; w<=SSelLEstN; w++)
     {
     for (v=1; v<=SLptN; v++) SelVec(v) = SSelLEst(w,v,s);
     SelSmooth_PSS += pen2diffs(SelVec, SelSmooth_SD);
     } // End loop on waypoint.
  // Compute penalty once only if males not split.
  if (SplitMalesFlag == 0) break;
  } // End loop on sex.
  //
  PSSTotal += SelSmooth_PSS;
}

void model_parameters::Compute_Catch_RSS(void)
{
  //
  // Compute RSS for catch at age/sex.
  //
  // Predict catch at observed age/sex.
  //
  SmearAges(CCatch_F, Catch_Pred_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(CCatch_M, Catch_Pred_M, TrueToSurf, TrueToBurn, NA);
  SmearAges(CCatch_T, Catch_Pred_T, TrueToSurf, TrueToBurn, NA);
  //
  // Compute RSS. Inclusion of sex-specific RSS depends on SexFlag.
  //
  Catch_RSS = 0.0;
  RSS_list = CalcRRSS(Catch_Pred_F, Catch_F, Catch_SE_F,
                      CatchTau_F, Robust,
                      CMinAge, CLastYearFit, NA);
  Catch_RSS_F = RSS_list(1);
  Catch_n_F = RSS_list(2);
  Catch_rms_F = sqrt(RSS_list(3));
  if (SexFlag==1) Catch_RSS += RSS_list(1);
  RSS_list = CalcRRSS(Catch_Pred_M, Catch_M, Catch_SE_M,
                      CatchTau_M, Robust,
                      CMinAge, CLastYearFit, NA);
  Catch_RSS_M = RSS_list(1);
  Catch_n_M = RSS_list(2);
  Catch_rms_M = sqrt(RSS_list(3));
  if (SexFlag==1) Catch_RSS += RSS_list(1);
  RSS_list = CalcRRSS(Catch_Pred_T, Catch_T, Catch_SE_T,
                      CatchTau_T, Robust,
                      CMinAge, CLastYearFit, NA);
  Catch_RSS_T = RSS_list(1);
  Catch_n_T = RSS_list(2);
  Catch_rms_T = sqrt(RSS_list(3));
  Catch_RSS += RSS_list(1);
  Catch_n = RSS_list(2);
  if (SexFlag==1) Catch_n = 3.0 * Catch_n;
  Catch_rms = sqrt(RSS_list(3));
  //
  RSSTotal += CatchLambda * Catch_RSS;
  if (CatchLambda > 0.0) RSSNobs += Catch_n;
  //
}

void model_parameters::Compute_CCPUE_RSS(void)
{
  //
  // Compute RSS for CCPUE at age/sex.
  //
  // Predict CCPUE at observed age/sex.
  //
  SmearAges(CCPUE_True_F, CCPUE_Pred_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(CCPUE_True_M, CCPUE_Pred_M, TrueToSurf, TrueToBurn, NA);
  SmearAges(CCPUE_True_T, CCPUE_Pred_T, TrueToSurf, TrueToBurn, NA);
  //
  // Compute RSS. Inclusion of sex-specific RSS depends on SexFlag.
  //
  CCPUE_RSS = 0.0;
  RSS_list = CalcRRSS(CCPUE_Pred_F, CCPUE_F, CCPUE_SE_F,
                      CCPUETau_F, Robust,
                      CMinAge, CLastYearFit, NA);
  CCPUE_RSS_F = RSS_list(1);
  CCPUE_n_F = RSS_list(2);
  CCPUE_rms_F = sqrt(RSS_list(3));
  if (SexFlag==1) CCPUE_RSS += RSS_list(1);
  RSS_list = CalcRRSS(CCPUE_Pred_M, CCPUE_M, CCPUE_SE_M,
                      CCPUETau_M, Robust,
                      CMinAge, CLastYearFit, NA);
  CCPUE_RSS_M = RSS_list(1);
  CCPUE_n_M = RSS_list(2);
  CCPUE_rms_M = sqrt(RSS_list(3));
  if (SexFlag==1) CCPUE_RSS += RSS_list(1);
  RSS_list = CalcRRSS(CCPUE_Pred_T, CCPUE_T, CCPUE_SE_T,
                      CCPUETau_T, Robust,
                      CMinAge, CLastYearFit, NA);
  CCPUE_RSS_T = RSS_list(1);
  CCPUE_n_T = RSS_list(2);
  CCPUE_rms_T = sqrt(RSS_list(3));
  CCPUE_RSS += RSS_list(1);
  CCPUE_n = RSS_list(2);
  if (SexFlag==1) CCPUE_n = 3.0 * CCPUE_n;
  CCPUE_rms = sqrt(RSS_list(3));
  //
  RSSTotal += CCPUELambda * CCPUE_RSS;
  if (CCPUELambda > 0.0) RSSNobs += CCPUE_n;
  //
}

void model_parameters::Compute_SurvProp_RSS(void)
{
  //
  // Compute RSS for SurvProp at age/sex.
  //
  // Predict SurvProp at observed age/sex.
  //
  SmearAges(SurvProp_True_F, SurvProp_Pred_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(SurvProp_True_M, SurvProp_Pred_M, TrueToSurf, TrueToBurn, NA);
  SmearAges(SurvProp_True_T, SurvProp_Pred_T, TrueToSurf, TrueToBurn, NA);
  //
  // The rows of SurvProp_Pred_T will not quite sum to one because a small
  // fraction of young fish will be smeared to ages less than e.g. 6. Normalize.
  dvariable SumProp;
  for (y=FirstYear; y<=LastYear; y++)
     {
     SumProp = 0.0;
     // Compute sum for this year.
     for (a=SMinAge; a<=SMaxAge; a++)
        {
        if (SurvProp_Pred_T(y,a) == NA) break;
        SumProp += SurvProp_Pred_T(y,a);
        }
     // Divide all proportions by this sum.
     for (a=SMinAge; a<=SMaxAge; a++)
        {
        if (SurvProp_Pred_T(y,a) == NA) break;
        SurvProp_Pred_F(y,a) /= SumProp;
        SurvProp_Pred_M(y,a) /= SumProp;
        SurvProp_Pred_T(y,a) /= SumProp;
        }
     } // End loop on year.
  //
  // Compute RSS. Inclusion of sex-specific RSS depends on SexFlag.
  //
  SurvProp_RSS = 0.0;
  RSS_list = CalcRRSS(SurvProp_Pred_F, SurvProp_F, SurvProp_SE_F,
                      SurvPropTau_F, Robust,
                      SMinAge, SLastYearFit, NA);
  SurvProp_RSS_F = RSS_list(1);
  SurvProp_n_F = RSS_list(2);
  SurvProp_rms_F = sqrt(RSS_list(3));
  if (SexFlag==1) SurvProp_RSS += RSS_list(1);
  RSS_list = CalcRRSS(SurvProp_Pred_M, SurvProp_M, SurvProp_SE_M,
                      SurvPropTau_M, Robust,
                      SMinAge, SLastYearFit, NA);
  SurvProp_RSS_M = RSS_list(1);
  SurvProp_n_M = RSS_list(2);
  SurvProp_rms_M = sqrt(RSS_list(3));
  if (SexFlag==1) SurvProp_RSS += RSS_list(1);
  RSS_list = CalcRRSS(SurvProp_Pred_T, SurvProp_T, SurvProp_SE_T,
                      SurvPropTau_T, Robust,
                      SMinAge, SLastYearFit, NA);
  SurvProp_RSS_T = RSS_list(1);
  SurvProp_n_T = RSS_list(2);
  SurvProp_rms_T = sqrt(RSS_list(3));
  SurvProp_RSS += RSS_list(1);
  SurvProp_n = RSS_list(2);
  if (SexFlag==1) SurvProp_n = 3.0 * SurvProp_n;
  SurvProp_rms = sqrt(RSS_list(3));
  //
  RSSTotal += SurvPropLambda * SurvProp_RSS;
  if (SurvPropLambda > 0.0) RSSNobs += SurvProp_n;
  //
}

void model_parameters::Compute_SurvCPUE_RSS(void)
{
  //
  // Compute RSS for SurvCPUE at age/sex.
  //
  // Predict SurvCPUE at observed age/sex.
  //
  SmearAges(SurvCPUE_True_F, SurvCPUE_Pred_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(SurvCPUE_True_M, SurvCPUE_Pred_M, TrueToSurf, TrueToBurn, NA);
  SmearAges(SurvCPUE_True_T, SurvCPUE_Pred_T, TrueToSurf, TrueToBurn, NA);
  //
  // Compute RSS. Inclusion of sex-specific RSS depends on SexFlag.
  //
  SurvCPUE_RSS = 0.0;
  RSS_list = CalcRRSS(SurvCPUE_Pred_F, SurvCPUE_F, SurvCPUE_SE_F,
                      SurvCPUETau_F, Robust,
                      SMinAge, SLastYearFit, NA);
  SurvCPUE_RSS_F = RSS_list(1);
  SurvCPUE_n_F = RSS_list(2);
  SurvCPUE_rms_F = sqrt(RSS_list(3));
  if (SexFlag==1) SurvCPUE_RSS += RSS_list(1);
  RSS_list = CalcRRSS(SurvCPUE_Pred_M, SurvCPUE_M, SurvCPUE_SE_M,
                      SurvCPUETau_M, Robust,
                      SMinAge, SLastYearFit, NA);
  SurvCPUE_RSS_M = RSS_list(1);
  SurvCPUE_n_M = RSS_list(2);
  SurvCPUE_rms_M = sqrt(RSS_list(3));
  if (SexFlag==1) SurvCPUE_RSS += RSS_list(1);
  RSS_list = CalcRRSS(SurvCPUE_Pred_T, SurvCPUE_T, SurvCPUE_SE_T,
                      SurvCPUETau_T, Robust,
                      SMinAge, SLastYearFit, NA);
  SurvCPUE_RSS_T = RSS_list(1);
  SurvCPUE_n_T = RSS_list(2);
  SurvCPUE_rms_T = sqrt(RSS_list(3));
  SurvCPUE_RSS += RSS_list(1);
  SurvCPUE_n = RSS_list(2);
  if (SexFlag==1) SurvCPUE_n = 3.0 * SurvCPUE_n;
  SurvCPUE_rms = sqrt(RSS_list(3));
  //
  RSSTotal += SurvCPUELambda * SurvCPUE_RSS;
  if (SurvCPUELambda > 0.0) RSSNobs += SurvCPUE_n;
  //
}

void model_parameters::Compute_CPUE_Totals_RSS(void)
{
  //
  // Compute RSS for commercial and survey total CPUE's in no. & weight.
  //
  // Compute the predictions.
  //
  for (y=FirstYear; y<=LastYear; y++)
     {
     if (y<=2001) AgePlus = AgePlusSurf; else AgePlus = AgePlusBurn;
     CCPUETot_Pred(y) = 0.0;
     CWPUETot_Pred(y) = 0.0;
     //
     SurvCPUETot_Pred(y) = 0.0;
     SurvWPUETot_Pred(y) = 0.0;
     for (a=SMinAge; a<=AgePlus; a++)
        {
        CCPUETot_Pred(y) += CCPUE_Pred_F(y,a) + CCPUE_Pred_M(y,a);
        CWPUETot_Pred(y) += CCPUE_Pred_F(y,a) * CatchW_F(y,a) +
                            CCPUE_Pred_M(y,a) * CatchW_M(y,a);
        SurvCPUETot_Pred(y) += SurvCPUE_Pred_F(y,a) + SurvCPUE_Pred_M(y,a);
        SurvWPUETot_Pred(y) += SurvCPUE_Pred_F(y,a) * SurvPropLegal_F(y,a) * SurvLegalW_F(y,a) +
                               SurvCPUE_Pred_M(y,a) * SurvPropLegal_M(y,a) * SurvLegalW_M(y,a);
        } // End loop on age.
     }  // End loop on year.
  //
  // Compute the RSS's.
  //
  RSS_list = CalcRRSS(CCPUETot_Pred, CCPUETot, CCPUETot_SE,
                      CCPUETotTau, Robust,
                      FirstYear, CLastYearFit, NA);
  CCPUETot_RSS = RSS_list(1);
  CCPUETot_n = RSS_list(2);
  CCPUETot_rms = sqrt(RSS_list(3));
  //
  RSS_list = CalcRRSS(CWPUETot_Pred, CWPUETot, CWPUETot_SE,
                      CWPUETotTau, Robust,
                      FirstYear, CLastYearFit, NA);
  CWPUETot_RSS = RSS_list(1);
  CWPUETot_n = RSS_list(2);
  CWPUETot_rms = sqrt(RSS_list(3));
  //
  RSS_list = CalcRRSS(SurvCPUETot_Pred, SurvCPUETot, SurvCPUETot_SE,
                      SurvCPUETotTau, Robust,
                      FirstYear, SLastYearFit, NA);
  SurvCPUETot_RSS = RSS_list(1);
  SurvCPUETot_n = RSS_list(2);
  SurvCPUETot_rms = sqrt(RSS_list(3));
  //
  RSS_list = CalcRRSS(SurvWPUETot_Pred, SurvWPUETot, SurvWPUETot_SE,
                      SurvWPUETotTau, Robust,
                      FirstYear, SLastYearFit, NA);
  SurvWPUETot_RSS = RSS_list(1);
  SurvWPUETot_n = RSS_list(2);
  SurvWPUETot_rms = sqrt(RSS_list(3));
  //
  RSSTotal += CCPUETotLambda * CCPUETot_RSS + 
              CWPUETotLambda * CWPUETot_RSS +
              SurvCPUETotLambda * SurvCPUETot_RSS +
              SurvWPUETotLambda * SurvWPUETot_RSS*survRSSmult;
  if (CCPUETotLambda > 0.0) RSSNobs += CCPUETot_n;
  if (CWPUETotLambda > 0.0) RSSNobs += CWPUETot_n;
  if (SurvCPUETotLambda > 0.0) RSSNobs += SurvCPUETot_n;
  if (SurvWPUETotLambda > 0.0) RSSNobs += SurvWPUETot_n;
  //
}

void model_parameters::Compute_DiscardWt_RSS(void)
{
  //
  // This is really simple because the average weight of sublegals
  // is 7.5 lb every year.
  //
  // Compute the predictions.
  for (y=FirstYear; y<= LastYear; y++)
     {
     DiscardWt_Pred(y) = 0.0;
     for (b=1; b<=LastAge; b++)
     for (s=1; s<=2; s++)
        DiscardWt_Pred(y) += 7.5 * DCatch(y,b,s);
     }
  //
  // Compute RSS.
  //
  RSS_list = CalcRRSS(DiscardWt_Pred, DiscardWt, XCatchWt_SE,
                     1.0, 0, // No variance scaling or robustification.
                     FirstYear, LastYear, NA);
  DiscardWt_RSS = RSS_list(1);
  DiscardWt_n = RSS_list(2);
  DiscardWt_rms = sqrt(RSS_list(3));
  RSSTotal += DiscardWt_RSS;
  RSSNobs += DiscardWt_n;
  //
}

void model_parameters::Compute_Bycatch_RSS(void)
{
  //
  // Compute RSS for bycatch in number at length.
  //
  for (y=FirstYear; y<=LastYear; y++)
     {
     // Zero out predicted bycatch nos. by length.
     for (v=1; v<=BLptN; v++) Bycatch_Pred(y,v) = 0.0;
     // Run though ages apportioning female bycatch.
     for (b=1; b<=LastAge; b++)
     for (v=1; v<=BLptN; v++)
        {
        LBot = BLptList(v);
        zBot = (LBot - BycatchLTrue_F(y,b)) / BycatchLSDTrue_F(y,b);
        if (v < BLptN) LTop = BLptList(v+1);
                   else  LTop = 250.0;
        zTop = (LTop - BycatchLTrue_F(y,b)) / BycatchLSDTrue_F(y,b);
        if (zTop < -3.0) continue;
        if (zBot >  3.0) break;
        LPorp = cumd_norm(zTop) - cumd_norm(zBot);
        Bycatch_Pred(y,v) += LPorp * BCatch_F(y,b);
        } // End age, lint loops for females.
     // Run though ages apportioning male bycatch.
     for (b=1; b<=LastAge; b++)
     for (v=1; v<=BLptN; v++)
        {
        LBot = BLptList(v);
        zBot = (LBot - BycatchLTrue_M(y,b)) / BycatchLSDTrue_M(y,b);
        if (v < BLptN) LTop = BLptList(v+1);
                   else  LTop = 250.0;
        zTop = (LTop - BycatchLTrue_M(y,b)) / BycatchLSDTrue_M(y,b);
        if (zTop < -3.0) continue;
        if (zBot >  3.0) break;
        LPorp = cumd_norm(zTop) - cumd_norm(zBot);
        Bycatch_Pred(y,v) += LPorp * BCatch_M(y,b);
        } // End age, lint loops for males.
     } // End loop on year.
  //
  // Compute RSS.
  RSS_list = CalcRRSS(Bycatch_Pred, Bycatch, Bycatch_SE,
                      BycatchTau, Robust, 1, LastYear, NA);
  Bycatch_RSS = RSS_list(1);
  Bycatch_n = RSS_list(2);
  Bycatch_rms = sqrt(RSS_list(3));
  if (FitBycatchNosFlag != 0) 
     {
     RSSTotal += BycatchLambda * Bycatch_RSS;
     RSSNobs += Bycatch_n;
     }
  //
}

void model_parameters::Compute_BycatchWt_RSS(void)
{
  //
  // Compute RSS for predicted total bycatch weight.
  //
  // Use weight at true age to compute bycatch prediction.
  //
  for (y=FirstYear; y<=LastYear; y++)
     {
     BycatchWt_Pred(y)=0.0;
     for (b=1; b<=LastAge; b++)
        BycatchWt_Pred(y) += BCatch_F(y,b) * BycatchWTrue_F(y,b) +
                             BCatch_M(y,b) * BycatchWTrue_M(y,b);
     }
  //
  // Compute RSS.
  //
  RSS_list = CalcRRSS(BycatchWt_Pred, BycatchWt, XCatchWt_SE,
                     1.0, 0, // No variance scaling or robustification.
                     FirstYear, LastYear, NA);
  BycatchWt_RSS = RSS_list(1);
  BycatchWt_n = RSS_list(2);
  BycatchWt_rms = sqrt(RSS_list(3));
  if (FitBycatchWtFlag != 0)
	{
	RSSTotal += BycatchLambda * BycatchWt_RSS;
	RSSNobs += BycatchWt_n;
	}
  //
}

void model_parameters::Compute_SportCatchWt_RSS(void)
{
  //
  // Smear ages and use survey weight at observed age for sport & persuse.
  //
  SmearAges(RCatch_F, SportCatch_Pred_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(RCatch_M, SportCatch_Pred_M, TrueToSurf, TrueToBurn, NA);
  //
  // Compute predictions.
  for (y=FirstYear; y<=LastYear; y++)
     {
     SportCatchWt_Pred(y) = 0.0;
     if (y<=2001) AgePlus = AgePlusSurf; else AgePlus = AgePlusBurn;
     for (a=SMinAge; a<=AgePlus; a++)
        SportCatchWt_Pred(y) += SportCatch_Pred_F(y,a) * SurvW_F(y,a) +
                                SportCatch_Pred_M(y,a) * SurvW_M(y,a);
     } // End year loop.
  //
  // Compute RSS.
  //
  RSS_list = CalcRRSS(SportCatchWt_Pred, SportCatchWt, XCatchWt_SE,
                      1.0, 0, // No variance scaling or robustification.
                      FirstYear, LastYear, NA);
  SportCatchWt_RSS = RSS_list(1);
  SportCatchWt_n = RSS_list(2);
  SportCatchWt_rms = sqrt(RSS_list(3));
  RSSTotal += SportCatchWt_RSS;
  RSSNobs += SportCatchWt_n;
  //
}

void model_parameters::Compute_PersUseWt_RSS(void)
{
  //
  // Smear ages and use survey weight at observed age for sport & persuse.
  //
  SmearAges(PCatch_F, PersUse_Pred_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(PCatch_M, PersUse_Pred_M, TrueToSurf, TrueToBurn, NA);
  //
  // Compute predictions.
  for (y=FirstYear; y<=LastYear; y++)
     {
     PersUseWt_Pred(y) = 0.0;
     if (y<=2001) AgePlus = AgePlusSurf; else AgePlus = AgePlusBurn;
     for (a=SMinAge; a<=AgePlus; a++)
        PersUseWt_Pred(y) += PersUse_Pred_F(y,a) * SurvW_F(y,a) +
                                PersUse_Pred_M(y,a) * SurvW_M(y,a);
     } // End year loop.
  //
  // Compute RSS.
  //
  RSS_list = CalcRRSS(PersUseWt_Pred, PersUseWt, XCatchWt_SE,
                     1.0, 0, // No variance scaling or robustification.
                     FirstYear, LastYear, NA);
  PersUseWt_RSS = RSS_list(1);
  PersUseWt_n = RSS_list(2);
  PersUseWt_rms = sqrt(RSS_list(3));
  RSSTotal += PersUseWt_RSS;
  RSSNobs += PersUseWt_n;
  //
}

void model_parameters::Compute_CatchN_RSS(void)
{
  //
  // Compute RSS for total annual catch in number.
  //
  for (y=FirstYear; y<=LastYear; y++)
     {
     if (y<=2001) AgePlus = AgePlusSurf; else AgePlus = AgePlusBurn;
     CatchN_Pred(y) = 0.0;
     for (a=CMinAge; a<=AgePlus; a++) CatchN_Pred(y) += Catch_Pred_T(y,a);
     }
  RSS_list = CalcRRSS(CatchN_Pred, CatchN, XCatchN_SE, 
                      1.0, 0, // No variance scaling or robustification.
                      FirstYear, LastYear, NA);
  CatchN_RSS = RSS_list(1);
  CatchN_n = RSS_list(2);
  CatchN_rms = sqrt(RSS_list(3));
  if (FitCatchNFlag != 0)
	{
	 RSSTotal += CatchN_RSS;
	 RSSNobs += CatchN_n;
	}
  //
}

void model_parameters::Compute_outputs(void)
{
  //
  // Compute values to be reported.
  //
  Deviance = RSSTotal/4.0;
  //
  // Unload 3D selectivity arrays to a matrix for each sex.
  for (y=FirstYear; y<=LastYear; y++)
  for (v=1; v<=SLptN; v++)
     {
     CSelL_F(y,v) = CSelL(y,v,1);
     CSelL_M(y,v) = CSelL(y,v,2);
     SSelL_F(y,v) = SSelL(y,v,1);
     SSelL_M(y,v) = SSelL(y,v,2);
     }
  for (y=FirstYear; y<=LastYear; y++)
  for (v=1; v<=BLptN; v++)
     {
     BSelL_F(y,v) = BSelL(y,v,1);
     BSelL_M(y,v) = BSelL(y,v,2);
     }
  //
  for (y=FirstYear; y<=LastYear; y++)
  for (b=1; b<=LastAge; b++)
     {
     CSel_F(y,b) = CSel(y,b,1);
     CSel_M(y,b) = CSel(y,b,2);
     DSel_F(y,b) = DSel(y,b,1);
     DSel_M(y,b) = DSel(y,b,2);
     FSel_F(y,b) = FSel(y,b,1);
     FSel_M(y,b) = FSel(y,b,2);
     SSel_F(y,b) = SSel(y,b,1);
     SSel_M(y,b) = SSel(y,b,2);
     BSel_F(y,b) = BSel(y,b,1);
     BSel_M(y,b) = BSel(y,b,2);
     Z_F(y,b)    = Z(y,b,1);
     Z_M(y,b)    = Z(y,b,2);
     }
  //
  // Compute commercial and survey exploitable numbers at true age.
  int yp; // Parameter year yp=y except in LastYear+1 when it is LastYear.
  for (y=FirstYear; y<=LastYear+1; y++)
     {
     if (y<=LastYear) yp = y; else yp = LastYear;
     for (b=1; b<=LastAge; b++)
        {
        CEN_F(y,b) = CSel_F(yp,b) * N_F(y,b);
        CEN_M(y,b) = CSel_M(yp,b) * N_M(y,b);
        FEN_F(y,b) = FSel_F(yp,b) * N_F(y,b);
        FEN_M(y,b) = FSel_M(yp,b) * N_M(y,b);
        SEN_F(y,b) = SSel_F(yp,b) * N_F(y,b);
        SEN_M(y,b) = SSel_M(yp,b) * N_M(y,b);
        }
     }
  //
  // Compute the usual measures of estimated abundance using the smeared
  // population at age/sex NS and observed weight at age.
  //
  SmearAges(N_F, NS_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(N_M, NS_M, TrueToSurf, TrueToBurn, NA);
  //
  SmearAges(CEN_F, CENS_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(CEN_M, CENS_M, TrueToSurf, TrueToBurn, NA);
  //
  SmearAges(FEN_F, FENS_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(FEN_M, FENS_M, TrueToSurf, TrueToBurn, NA);
  //
  SmearAges(SEN_F, SENS_F, TrueToSurf, TrueToBurn, NA);
  SmearAges(SEN_M, SENS_M, TrueToSurf, TrueToBurn, NA);
  //
  int yd; // Data year yd=year except in YearLastDat+1 it is YearLastDat.
  for (y=FirstYear; y<=LastYear+1; y++)
     {
     R6(y) = N_F(y,6) + N_M(y,6);
     R8(y) = N_F(y,8) + N_M(y,8);
     R8SD(y) = R8(y);
     //
     // Initialize accumulators.
     N8Plus_F(y) = 0.0;
     N8Plus_M(y) = 0.0;
     TBio8Plus_F(y) = 0.0;
     TBio8Plus_M(y) = 0.0;
     LBio(y) = 0.0;
     SBio(y) = 0.0;
     EBio(y) = 0.0;
     EBioFixed(y) = 0.0;
     EBioSurv(y) = 0.0;
     //
     // Run through observed ages.
     if (y<=2001) AgePlus = AgePlusSurf; else AgePlus = AgePlusBurn;
     if (y<=YearLastDat) yd = y; else yd = YearLastDat;
     for (a=SMinAge; a<=AgePlus; a++)
        {
        LBio(y) += NS_F(y,a) * SurvPropLegal_F(yd,a) * SurvLegalW_F(yd,a) +
                   NS_M(y,a) * SurvPropLegal_M(yd,a) * SurvLegalW_M(yd,a);
        SBio(y) += PropMat(a) * NS_F(y,a) * SurvW_F(yd,a);
        EBio(y) += CENS_F(y,a) * CatchW_F(yd,a) + CENS_M(y,a) * CatchW_M(yd,a);
        EBioFixed(y) += FENS_F(y,a) * CatchW_F(yd,a) + FENS_M(y,a) * CatchW_M(yd,a);
        EBioSurv(y) += SENS_F(y,a) * SurvW_F(yd,a) + SENS_M(y,a) * SurvW_M(yd,a);
        //
        if (a < 8) continue;  // Other measures are ages 8+.
        N8Plus_F(y) += NS_F(y,a);
        N8Plus_M(y) += NS_M(y,a);
        TBio8Plus_F(y) += NS_F(y,a) * SurvW_F(yd,a);
        TBio8Plus_M(y) += NS_M(y,a) * SurvW_M(yd,a);
        } // End loop on observed age.
     }  // End loop on year.
  LastEBioFixed = EBioFixed(LastYear+1);
  LastEBioFixedToo = EBioFixed(LastYear+1);
  LastSBio = SBio(LastYear+1);
  //
}

void model_parameters::report()
{
 adstring ad_tmp=initial_params::get_reportfile_name();
  ofstream report((char*)(adprogram_name + ad_tmp));
  if (!report)
  {
    cerr << "error trying to open report file"  << adprogram_name << ".rep";
    return;
  }
  //    
  // Report values to be reported.
  //
  Compute_outputs();
  ofstream rep("legacy.rep");
  //
  rep << "Area" << endl << Area << endl;
  rep << "SQ_bhat" << endl << SQ_bhat << endl;
  rep << "FirstYear" << endl << FirstYear << endl;
  rep << "LastYear" << endl << LastYear << endl;
  rep << "LastYearClass" << endl << LastYearClass << endl;
  rep << "MinusLogL" << endl << MinusLogL << endl;
  rep << "Deviance" << endl << Deviance << endl;
  rep << "RSSNobs" << endl << RSSNobs << endl;
  rep << "CatchWt" << endl << CatchWt/1.0E6 << endl;
  rep << "MPar" << endl << MPar << " " << MPar_M << endl;
  rep << "PropFem" << endl << PropFem << endl;
  rep << "R6" << endl << R6/1.0E6 << endl;
  rep << "R8" << endl << R8/1.0E6 << endl;
  rep << "EBio" << endl << EBio/1.0E6 << endl;
  rep << "EBioFixed" << endl << EBioFixed/1.0E6 << endl;
  rep << "EBioSurv" << endl << EBioSurv/1.0E6 << endl;
  rep << "SBio" << endl << SBio/1.0E6 << endl;
  rep << "LBio" << endl << LBio/1.0E6 << endl;
  rep << "N8Plus.F" << endl << N8Plus_F/1.0E6 << endl;
  rep << "N8Plus.M" << endl << N8Plus_M/1.0E6 << endl;
  rep << "TBio8Plus.F" << endl << TBio8Plus_F/1.0E6 << endl;
  rep << "TBio8Plus.M" << endl << TBio8Plus_M/1.0E6 << endl;
  rep << "M" << endl << M << endl;
  rep << "CF" << endl << CF << endl;
  rep << "Z.F" << endl << Z_F << endl;
  rep << "Z.M" << endl << Z_M << endl;
  rep << "CQMX" << endl << CQMX << endl;
  rep << "CQ" << endl << CQ << endl;
  rep << "CSelL.F" << endl << CSelL_F << endl;
  rep << "CSelL.M" << endl << CSelL_M << endl;
  rep << "CSel.F" << endl << CSel_F << endl;
  rep << "CSel.M" << endl << CSel_M << endl;
  rep << "SQMX" << endl << SQMX << endl;
  rep << "SQ" << endl << SQ << endl;
  rep << "SSelL.F" << endl << SSelL_F << endl;
  rep << "SSelL.M" << endl << SSelL_M << endl;
  rep << "SSel.F" << endl << SSel_F << endl;
  rep << "SSel.M" << endl << SSel_M << endl;
  rep << "DFPar" << endl << DFPar << endl;
  rep << "RFPar" << endl << RFPar << endl;
  rep << "PFPar" << endl << PFPar << endl;
  rep << "DSelL.F" << endl << DSel_F << endl;
  rep << "BF" << endl << BF << endl;
  rep << "BSelL.F" << endl << BSelL_F << endl;
  rep << "BSelL.M" << endl << BSelL_M << endl;
  rep << "BSel.F" << endl << BSel_F << endl;
  rep << "BSel.M" << endl << BSel_M << endl;
  rep << "FSel.F:" << endl << FSel_F << endl;
  rep << "FSel.M:" << endl << FSel_M << endl;
  rep << "R" << endl << R << endl;
  rep << "InitN" << endl << InitN << endl;
  //
  rep << "N.F" << endl << N_F << endl;
  rep << "N.M" << endl << N_M << endl;
  rep << "NS.F" << endl << NS_F << endl;
  rep << "NS.M" << endl << NS_M << endl;
  rep << "CENS.F" << endl << CENS_F << endl;
  rep << "CENS.M" << endl << CENS_M << endl;
  rep << "FENS.F" << endl << FENS_F << endl;
  rep << "FENS.M" << endl << FENS_M << endl;
  rep << "CatchW.F" << endl << CatchW_F << endl;
  rep << "CatchW.M" << endl << CatchW_M << endl;
  rep << "Catch.F" << endl << Catch_F << endl;
  rep << "Catch.Pred.F" << endl << Catch_Pred_F << endl;
  rep << "Catch.SE.F" << endl << Catch_SE_F << endl;
  rep << "Catch.M" << endl << Catch_M << endl;
  rep << "Catch.Pred.M" << endl << Catch_Pred_M << endl;
  rep << "Catch.SE.M" << endl << Catch_SE_M << endl;
  rep << "Catch.T" << endl << Catch_T << endl;
  rep << "Catch.Pred.T" << endl << Catch_Pred_T << endl;
  rep << "Catch.SE.T" << endl << Catch_SE_T << endl;
  rep << "CCPUE.F" << endl << CCPUE_F << endl;
  rep << "CCPUE.Pred.F" << endl << CCPUE_Pred_F << endl;
  rep << "CCPUE.SE.F" << endl << CCPUE_SE_F << endl;
  rep << "CCPUE.M" << endl << CCPUE_M << endl;
  rep << "CCPUE.Pred.M" << endl << CCPUE_Pred_M << endl;
  rep << "CCPUE.SE.M" << endl << CCPUE_SE_M << endl;
  rep << "CCPUE.T" << endl << CCPUE_T << endl;
  rep << "CCPUE.Pred.T" << endl << CCPUE_Pred_T << endl;
  rep << "CCPUE.SE.T" << endl << CCPUE_SE_T << endl;
  rep << "CCPUETot" << endl << CCPUETot << endl;
  rep << "CCPUETot.Pred" << endl << CCPUETot_Pred << endl;
  rep << "CCPUETot.SE" << endl << CCPUETot_SE << endl;
  rep << "CWPUETot" << endl << CWPUETot << endl;
  rep << "CWPUETot.Pred" << endl << CWPUETot_Pred << endl;
  rep << "CWPUETot.SE" << endl << CWPUETot_SE << endl;
  rep << "SurvProp.F" << endl << SurvProp_F << endl;
  rep << "SurvProp.Pred.F" << endl << SurvProp_Pred_F << endl;
  rep << "SurvProp.SE.F" << endl << SurvProp_SE_F << endl;
  rep << "SurvProp.M" << endl << SurvProp_M << endl;
  rep << "SurvProp.Pred.M" << endl << SurvProp_Pred_M << endl;
  rep << "SurvProp.SE.M" << endl << SurvProp_SE_M << endl;
  rep << "SurvProp.T" << endl << SurvProp_T << endl;
  rep << "SurvProp.Pred.T" << endl << SurvProp_Pred_T << endl;
  rep << "SurvProp.SE.T" << endl << SurvProp_SE_T << endl;
  rep << "SurvCPUE.True.F" << endl << SurvCPUE_True_F << endl;
  rep << "SurvCPUE.F" << endl << SurvCPUE_F << endl;
  rep << "SurvCPUE.Pred.F" << endl << SurvCPUE_Pred_F << endl;
  rep << "SurvCPUE.SE.F" << endl << SurvCPUE_SE_F << endl;
  rep << "SurvCPUE.True.M" << endl << SurvCPUE_True_M << endl;
  rep << "SurvCPUE.M" << endl << SurvCPUE_M << endl;
  rep << "SurvCPUE.Pred.M" << endl << SurvCPUE_Pred_M << endl;
  rep << "SurvCPUE.SE.M" << endl << SurvCPUE_SE_M << endl;
  rep << "SurvCPUE.True.T" << endl << SurvCPUE_True_T << endl;
  rep << "SurvCPUE.T" << endl << SurvCPUE_T << endl;
  rep << "SurvCPUE.Pred.T" << endl << SurvCPUE_Pred_T << endl;
  rep << "SurvCPUE.SE.T" << endl << SurvCPUE_SE_T << endl;
  rep << "SurvCPUETot" << endl << SurvCPUETot << endl;
  rep << "SurvCPUETot.Pred" << endl << SurvCPUETot_Pred << endl;
  rep << "SurvCPUETot.SE" << endl << SurvCPUETot_SE << endl;
  rep << "SurvWPUETot" << endl << SurvWPUETot << endl;
  rep << "SurvWPUETot.Pred" << endl << SurvWPUETot_Pred << endl;
  rep << "SurvWPUETot.SE" << endl << SurvWPUETot_SE << endl;
  rep << "DiscardWt" << endl << DiscardWt/1.0E6 << endl;
  rep << "DiscardWt.Pred" << endl << DiscardWt_Pred/1.0E6 << endl;
  rep << "Bycatch" << endl << Bycatch << endl;
  rep << "Bycatch.SE" << endl << Bycatch_SE << endl;
  rep << "Bycatch.Pred" << endl << Bycatch_Pred << endl;
  rep << "BycatchWt" << endl << BycatchWt/1.0E6 << endl;
  rep << "BycatchWt.Pred" << endl << BycatchWt_Pred/1.0E6 << endl;
  rep << "SportCatchWt" << endl << SportCatchWt/1.0E6 << endl;
  rep << "SportCatchWt.Pred" << endl << SportCatchWt_Pred/1.0E6 << endl;
  rep << "PersUseWt" << endl << PersUseWt/1.0E6 << endl;
  rep << "PersUseWt.Pred" << endl << PersUseWt_Pred/1.0E6 << endl;
  rep << "CatchN" << endl << CatchN/1.0E6 << endl;
  rep << "CatchN.Pred" << endl << CatchN_Pred/1.0E6 << endl;
  //
  ofstream ss("legacy.ss");
  //
  ss << "SSTotal " <<  SSTotal << endl;
  ss << endl;
  ss << "RSSTotal " << RSSTotal << endl;
  ss << "RSSNobs " << RSSNobs << endl;
  ss << "CatchLambda " << CatchLambda << endl;
  ss << "Catch_RSS_F & _M & _T " << Catch_RSS_F << " " << Catch_RSS_M << " " << Catch_RSS_T << endl;
  ss << "Catch_n_F & _M & _T " << Catch_n_F << " " << Catch_n_M << " " << Catch_n_T << endl;
  ss << "Catch_rms_F & _M & _T " << Catch_rms_F << " " << Catch_rms_M << " " << Catch_rms_T << endl;
  ss << "CCPUELambda " << CCPUELambda << endl;
  ss << "CCPUE_RSS_F & _M & _T " << CCPUE_RSS_F << " " << CCPUE_RSS_M << " " << CCPUE_RSS_T << endl;
  ss << "CCPUE_n_F & _M & _T " << CCPUE_n_F << " " << CCPUE_n_M << " " << CCPUE_n_T << endl;
  ss << "CCPUE_rms_F & _M & _T " << CCPUE_rms_F << " " << CCPUE_rms_M << " " << CCPUE_rms_T << endl;
  ss << "CCPUETotLambda " << CCPUETotLambda << endl;
  ss << "CCPUETot_RSS & _n & _rms " << CCPUETot_RSS << " " << CCPUETot_n << " " << CCPUETot_rms << endl;
  ss << "CWPUETotLambda " << CWPUETotLambda << endl;
  ss << "CWPUETot_RSS & _n & _rms " << CWPUETot_RSS << " " << CWPUETot_n << " " << CWPUETot_rms << endl;
  ss << "SurvCPUELambda " << SurvCPUELambda << endl;
  ss << "SurvCPUE_RSS_F & _M & _T " << SurvCPUE_RSS_F << " " << SurvCPUE_RSS_M << " " << SurvCPUE_RSS_T << endl;
  ss << "SurvCPUE_n_F & _M & _T " << SurvCPUE_n_F << " " << SurvCPUE_n_M << " " << SurvCPUE_n_T << endl;
  ss << "SurvCPUE_rms_F & _M & _T " << SurvCPUE_rms_F << " " << SurvCPUE_rms_M << " " << SurvCPUE_rms_T << endl;
  ss << "SurvCPUETotLambda " << SurvCPUETotLambda << endl;
  ss << "SurvCPUETot_RSS & _n & _rms " << SurvCPUETot_RSS << " " << SurvCPUETot_n << " " << SurvCPUETot_rms << endl;
  ss << "SurvWPUETotLambda " << SurvWPUETotLambda << endl;
  ss << "SurvWPUETot_RSS & _n & _rms " << SurvWPUETot_RSS << " " << SurvWPUETot_n << " " << SurvWPUETot_rms << endl;
  ss << "SurvPropLambda " << SurvPropLambda << endl;
  ss << "SurvProp_RSS_F & _M & _T " << SurvProp_RSS_F << " " << SurvProp_RSS_M << " " << SurvProp_RSS_T << endl;
  ss << "SurvProp_n_F & _M & _T " << SurvProp_n_F << " " << SurvProp_n_M << " " << SurvProp_n_T << endl;
  ss << "SurvProp_rms_F & _M & _T " << SurvProp_rms_F << " " << SurvProp_rms_M << " " << SurvProp_rms_T << endl;
  ss << "Bycatch_RSS " << BycatchLambda << endl;
  ss << "Bycatch_RSS  & _n & _rms " << Bycatch_RSS << " " << Bycatch_n << " " << Bycatch_rms << endl;
  ss << "BycatchWt_RSS " << BycatchLambda << endl;
  ss << "BycatchWt_RSS  & _n & _rms " << BycatchWt_RSS << " " << BycatchWt_n << " " << BycatchWt_rms << endl;
  ss << "DiscardWt_RSS  & _n & _rms " << DiscardWt_RSS << " " << DiscardWt_n << " " << DiscardWt_rms << endl;
  ss << "SportCatchWt_RSS  & _n & _rms " << SportCatchWt_RSS << " " << SportCatchWt_n << " " << SportCatchWt_rms << endl;
  ss << "PersUseWt_RSS  & _n & _rms " << PersUseWt_RSS << " " << PersUseWt_n << " " << PersUseWt_rms << endl;
  ss << "CatchN_RSS  & _n & _rms " << CatchN_RSS << " " << CatchN_n << " " << CatchN_rms << endl;
  ss << endl;
  ss << "PSSTotal " << PSSTotal << endl;
  ss << "SteadyCQ_PSS " << SteadyCQ_PSS << endl;
  ss << "SteadySQ_PSS " << SteadySQ_PSS << endl;
  ss << "TrendlessSQ_PSS " << TrendlessSQ_PSS << endl;
  ss << "SelSmooth_PSS " << SelSmooth_PSS << endl;
  ss << "UnevenSexRatio_PSS " << UnevenSexRatio_PSS << endl;
  ss << "WildYearClass_PSS " << WildYearClass_PSS << endl;
  ss << "WildR_PSS " << WildR_PSS << endl;
  ss << "LastF_PSS " << LastF_PSS << endl;
  //
}

void model_parameters::set_runtime(void)
{
  dvector temp1("{10000}");
  maximum_function_evaluations.allocate(temp1.indexmin(),temp1.indexmax());
  maximum_function_evaluations=temp1;
  dvector temp("{1.0E-4}");
  convergence_criteria.allocate(temp.indexmin(),temp.indexmax());
  convergence_criteria=temp;
}

void model_parameters::preliminary_calculations(void){
  admaster_slave_variable_interface(*this);
}

model_data::~model_data()
{}

model_parameters::~model_parameters()
{}

void model_parameters::final_calcs(void){}

#ifdef _BORLANDC_
  extern unsigned _stklen=10000U;
#endif


#ifdef __ZTC__
  extern unsigned int _stack=10000U;
#endif

  long int arrmblsize=0;

int main(int argc,char * argv[])
{
    ad_set_new_handler();
  ad_exit=&ad_boundf;
  gradient_structure::set_GRADSTACK_BUFFER_SIZE(200000);
  gradient_structure::set_CMPDIF_BUFFER_SIZE(1000000);
  gradient_structure::set_MAX_NVAR_OFFSET(1000);
  arrmblsize=2000000;
  //
    gradient_structure::set_NO_DERIVATIVES();
    gradient_structure::set_YES_SAVE_VARIABLES_VALUES();
  #if defined(__GNUDOS__) || defined(DOS386) || defined(__DPMI32__)  || \
     defined(__MSVC32__)
      if (!arrmblsize) arrmblsize=150000;
  #else
      if (!arrmblsize) arrmblsize=25000;
  #endif
    model_parameters mp(arrmblsize,argc,argv);
    mp.iprint=10;
    mp.preliminary_calculations();
    mp.computations(argc,argv);
    return 0;
}

extern "C"  {
  void ad_boundf(int i)
  {
    /* so we can stop here */
    exit(i);
  }
}
